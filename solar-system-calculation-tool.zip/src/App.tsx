import { useState, useMemo, useEffect } from 'react';
import { Appliance, SystemConfig } from './types';
import ApplianceForm from './components/ApplianceForm';
import ApplianceList from './components/ApplianceList';
import SystemConfigComponent from './components/SystemConfig';
import Results from './components/Results';
import FormulaCheatSheet from './components/FormulaCheatSheet';
import { calculateSolarSystem, getRecommendedVoltage } from './utils/calculations';
import { PROVINCES } from './data/pakistanData';

type Tab = 'appliances' | 'configuration' | 'results' | 'learn';

const defaultConfig: SystemConfig = {
  province: 'punjab',
  districtIndex: 0,
  systemMode: 'hybrid',
  batteryType: 'tall-tubular',
  panelType: 'monocrystalline',
  controllerType: 'mppt',
  inverterType: 'hybrid',
  autonomyDays: 1,
  systemVoltage: 12,
  useAutoVoltage: true,
};

function App() {
  const [activeTab, setActiveTab] = useState<Tab>('appliances');

  // Scroll to top whenever tab changes (smooth transition)
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [activeTab]);
  const [appliances, setAppliances] = useState<Appliance[]>([]);
  const [config, setConfig] = useState<SystemConfig>(defaultConfig);

  const addAppliance = (appliance: Omit<Appliance, 'id'>) => {
    const newAppliance: Appliance = {
      ...appliance,
      id: Date.now().toString() + Math.random().toString(36).substring(2, 9),
    };
    setAppliances([...appliances, newAppliance]);
  };

  const removeAppliance = (id: string) => {
    setAppliances(appliances.filter((a) => a.id !== id));
  };

  const toggleAppliance = (id: string) => {
    setAppliances(
      appliances.map((a) =>
        a.id === id ? { ...a, enabled: !a.enabled } : a
      )
    );
  };

  const updateAppliance = (id: string, updates: Partial<Appliance>) => {
    setAppliances(
      appliances.map((a) =>
        a.id === id ? { ...a, ...updates } : a
      )
    );
  };

  const updateConfig = (key: keyof SystemConfig, value: SystemConfig[keyof SystemConfig]) => {
    setConfig((prev) => {
      let next = { ...prev, [key]: value } as SystemConfig;

      if (key === 'batteryType' && value === 'tall-tubular') {
        next = {
          ...next,
          useAutoVoltage: false,
          systemVoltage: 12,
        };
      } else if (key === 'batteryType' && value !== 'tall-tubular' && prev.useAutoVoltage) {
        const autoVoltage = getRecommendedVoltage(rawDailyWh) as SystemConfig['systemVoltage'];
        next = {
          ...next,
          useAutoVoltage: true,
          systemVoltage: autoVoltage,
        };
      }

      return next;
    });
  };

  const handleProvinceChange = (province: string) => {
    setConfig(prev => ({
      ...prev,
      province: province as SystemConfig['province'],
      districtIndex: 0, // Reset district when province changes
    }));
  };

  // Calculate raw daily consumption (before inverter loss adjustment)
  const rawDailyWh = useMemo(() => {
    const enabledAppliances = appliances.filter(a => a.enabled);
    return enabledAppliances.reduce((sum, a) => sum + (a.watts * a.quantity * a.hoursPerDay), 0);
  }, [appliances]);

  // Calculate results
  const results = useMemo(() => {
    return calculateSolarSystem(appliances, config);
  }, [appliances, config]);

  // Get selected location info
  const selectedProvince = PROVINCES[config.province];
  const selectedDistrict = selectedProvince.districts[config.districtIndex];

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-teal-50 to-cyan-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex flex-col gap-4">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <h1 className="text-3xl font-bold flex items-center gap-3">
                  <span className="text-4xl">🌞</span>
                  Solar System Calculator
                </h1>
                <p className="text-emerald-100 mt-1">🇵🇰 Pakistan Edition - Design your perfect solar setup</p>
              </div>
              
              {/* Quick Location Display */}
              <div className="bg-white/20 rounded-xl px-4 py-2">
                <p className="text-xs text-emerald-100">Current Location</p>
                <p className="font-semibold">{selectedDistrict.name}, {selectedProvince.name}</p>
                <p className="text-sm text-emerald-100">☀️ {config.customPsh || selectedDistrict.psh} PSH</p>
              </div>
            </div>
            
            {/* Tab Navigation - Now includes all 4 tabs */}
            <div className="flex flex-wrap bg-white/20 rounded-xl p-1 gap-1">
              <button
                onClick={() => setActiveTab('appliances')}
                className={`flex-1 min-w-[120px] px-4 py-2 rounded-lg font-medium transition flex items-center justify-center gap-2 ${
                  activeTab === 'appliances'
                    ? 'bg-white text-emerald-700'
                    : 'text-white hover:bg-white/10'
                }`}
              >
                <span>🏠</span>
                <span className="hidden sm:inline">Appliances</span>
                <span className="sm:hidden">Load</span>
              </button>
              <button
                onClick={() => setActiveTab('configuration')}
                className={`flex-1 min-w-[120px] px-4 py-2 rounded-lg font-medium transition flex items-center justify-center gap-2 ${
                  activeTab === 'configuration'
                    ? 'bg-white text-emerald-700'
                    : 'text-white hover:bg-white/10'
                }`}
              >
                <span>⚙️</span>
                <span className="hidden sm:inline">Configuration</span>
                <span className="sm:hidden">Config</span>
              </button>
              <button
                onClick={() => setActiveTab('results')}
                className={`flex-1 min-w-[120px] px-4 py-2 rounded-lg font-medium transition flex items-center justify-center gap-2 ${
                  activeTab === 'results'
                    ? 'bg-white text-emerald-700'
                    : 'text-white hover:bg-white/10'
                }`}
              >
                <span>📊</span>
                <span className="hidden sm:inline">Results</span>
                <span className="sm:hidden">Results</span>
              </button>
              <button
                onClick={() => setActiveTab('learn')}
                className={`flex-1 min-w-[120px] px-4 py-2 rounded-lg font-medium transition flex items-center justify-center gap-2 ${
                  activeTab === 'learn'
                    ? 'bg-white text-emerald-700'
                    : 'text-white hover:bg-white/10'
                }`}
              >
                <span>📚</span>
                <span className="hidden sm:inline">Learn</span>
                <span className="sm:hidden">Learn</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Quick Stats Banner - Always visible */}
        <div className="bg-white rounded-2xl shadow-lg p-4 border border-gray-100 mb-8">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-center">
            <div className="border-r border-gray-200 pr-4">
              <p className="text-xs text-gray-500">Appliances</p>
              <p className="text-xl font-bold text-gray-800">{appliances.filter(a => a.enabled).length}</p>
            </div>
            <div className="border-r border-gray-200 pr-4">
              <p className="text-xs text-gray-500">Daily Load</p>
              <p className="text-xl font-bold text-emerald-600">{Math.round(rawDailyWh).toLocaleString()} Wh</p>
            </div>
            <div className="border-r border-gray-200 pr-4">
              <p className="text-xs text-gray-500">Solar Array</p>
              <p className="text-xl font-bold text-yellow-600">{results.actualSolarWatts} W</p>
            </div>
            <div className="border-r border-gray-200 pr-4">
              <p className="text-xs text-gray-500">Battery Bank</p>
              <p className="text-xl font-bold text-blue-600">{results.batteryCount}× {results.batteryAh}Ah</p>
            </div>
            <div>
              <p className="text-xs text-gray-500">System Voltage</p>
              <p className="text-xl font-bold text-purple-600">{results.recommendedVoltage}V</p>
              <p className="text-[10px] text-gray-400">{config.useAutoVoltage ? '(Auto)' : '(Manual)'}</p>
            </div>
          </div>
        </div>

        {/* Tab Content */}
        {activeTab === 'appliances' && (
          <div className="space-y-8">
            {/* Appliance Form */}
            <section>
              <ApplianceForm onAddAppliance={addAppliance} />
            </section>

            {/* Appliance List */}
            <section>
              <ApplianceList
                appliances={appliances}
                onRemove={removeAppliance}
                onToggle={toggleAppliance}
                onUpdate={updateAppliance}
              />
            </section>

            {/* Next Step Prompt */}
            {appliances.length > 0 && (
              <div className="bg-gradient-to-r from-emerald-500 to-teal-600 rounded-2xl p-6 text-white text-center">
                <p className="text-lg">✅ You've added {appliances.length} appliance(s)</p>
                <p className="text-emerald-100 mt-2">Configure your location and system settings for accurate calculations</p>
                <button
                  onClick={() => setActiveTab('configuration')}
                  className="mt-4 px-6 py-3 bg-white text-emerald-700 rounded-xl font-semibold hover:bg-emerald-50 transition"
                >
                  Next: Configure System ⚙️
                </button>
              </div>
            )}
          </div>
        )}

        {activeTab === 'configuration' && (
          <div className="space-y-8">
            <SystemConfigComponent
              config={config}
              onChange={updateConfig}
              onProvinceChange={handleProvinceChange}
              totalDailyWh={rawDailyWh}
            />

            {/* Next Step Prompt */}
            {appliances.length > 0 && (
              <div className="bg-gradient-to-r from-blue-500 to-indigo-600 rounded-2xl p-6 text-white text-center">
                <p className="text-lg">⚙️ Configuration Complete!</p>
                <p className="text-blue-100 mt-2">View your complete solar system requirements and shopping list</p>
                <button
                  onClick={() => setActiveTab('results')}
                  className="mt-4 px-6 py-3 bg-white text-blue-700 rounded-xl font-semibold hover:bg-blue-50 transition"
                >
                  View Results 📊
                </button>
              </div>
            )}

            {appliances.length === 0 && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-2xl p-6 text-center">
                <p className="text-lg text-yellow-800">⚠️ No appliances added yet</p>
                <p className="text-yellow-600 mt-2">Add your appliances first to see accurate calculations</p>
                <button
                  onClick={() => setActiveTab('appliances')}
                  className="mt-4 px-6 py-3 bg-yellow-500 text-white rounded-xl font-semibold hover:bg-yellow-600 transition"
                >
                  Add Appliances 🏠
                </button>
              </div>
            )}
          </div>
        )}

        {activeTab === 'results' && (
          <div className="space-y-8">
            {appliances.length > 0 ? (
              <Results results={results} config={config} />
            ) : (
              <div className="bg-yellow-50 border border-yellow-200 rounded-2xl p-6 text-center">
                <p className="text-lg text-yellow-800">⚠️ No appliances added yet</p>
                <p className="text-yellow-600 mt-2">Add your appliances first to see the results</p>
                <button
                  onClick={() => setActiveTab('appliances')}
                  className="mt-4 px-6 py-3 bg-yellow-500 text-white rounded-xl font-semibold hover:bg-yellow-600 transition"
                >
                  Add Appliances 🏠
                </button>
              </div>
            )}
          </div>
        )}

        {activeTab === 'learn' && (
          <FormulaCheatSheet />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h4 className="font-bold text-lg mb-3">🌞 Solar Calculator PK</h4>
              <p className="text-gray-400 text-sm">
                Design your solar system for Pakistan's unique conditions. 
                Supports Tall Tubular, Sodium-Ion, and Lithium batteries.
              </p>
            </div>
            <div>
              <h4 className="font-bold text-lg mb-3">📐 Key Formulas</h4>
              <ul className="text-gray-400 text-sm space-y-1">
                <li>• Solar: (Wh ÷ PSH) × 1.25</li>
                <li>• Battery: (Wh ÷ V) ÷ DoD</li>
                <li>• Controller: (Watts ÷ V) × 1.25</li>
                <li>• Generation: Panel W × PSH × 0.8</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-lg mb-3">🔋 Battery Types</h4>
              <ul className="text-gray-400 text-sm space-y-1">
                <li>• Tall Tubular: 50% DoD, 3-5 years</li>
                <li>• Sodium-Ion: 90% DoD, 8-12 years</li>
                <li>• Lithium: 85% DoD, 10+ years</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-6 text-center text-gray-500 text-sm">
            <p>⚡ Designed for Pakistani solar installations | All calculations are estimates</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
