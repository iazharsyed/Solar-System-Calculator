import { 
  Appliance, 
  SystemConfig, 
  CalculationResult, 
  WireRecommendation
} from '../types';
import { 
  PROVINCES,
  BATTERY_SPECS, 
  PANEL_SPECS, 
  CONTROLLER_SPECS, 
  INVERTER_SPECS,
  STANDARD_BATTERY_SIZES,
  STANDARD_PANEL_SIZES,
  STANDARD_CONTROLLER_SIZES,
  STANDARD_INVERTER_SIZES,
  WIRE_GAUGE_TABLE
} from '../data/pakistanData';

// ============================================
// GOLD STANDARD FORMULAS (Pakistan Edition)
// ============================================
// 1. Panel Sizing: Daily Wh / PSH / 0.8 = Daily Wh / PSH × 1.25
// 2. Panel Generation: Panel Watts × PSH × 0.8
// 3. Battery Sizing: (Daily Wh / Voltage) / DoD
// 4. Controller: (Panel Watts / Voltage) × 1.25
// 5. Inverter: Peak AC Watts × 1.25
// ============================================

const EFFICIENCY_FACTOR = 0.8; // 80% efficiency (or divide by this = multiply by 1.25)
const DUST_HEAT_FACTOR = 1.25; // 1 / 0.8 = 1.25 for sizing
const INVERTER_LOSS_FACTOR = 1.20; // 20% loss for AC systems
const CONTROLLER_SAFETY_FACTOR = 1.25; // 25% safety margin
const INVERTER_SAFETY_FACTOR = 1.25; // 25% safety margin

// Get wire gauge based on current
function getWireGauge(amps: number): { awg: number; mmSq: number } {
  for (const gauge of WIRE_GAUGE_TABLE) {
    if (amps <= gauge.maxAmps) {
      return { awg: gauge.awg, mmSq: gauge.mmSq };
    }
  }
  return { awg: 0, mmSq: 70 }; // Largest size
}

// Find next standard size (round UP)
function findNextStandardSize(value: number, sizes: number[]): number {
  for (const size of sizes) {
    if (size >= value) return size;
  }
  return sizes[sizes.length - 1];
}

// Determine recommended system voltage based on load
export function getRecommendedVoltage(totalWh: number): number {
  if (totalWh < 1000) return 12;
  if (totalWh <= 3000) return 24;
  return 48;
}

// Get battery configuration string (e.g., "2S2P")
function getBatteryConfig(
  totalBatteries: number, 
  systemVoltage: number, 
  batteryVoltage: number = 12
): string {
  const batteriesInSeries = systemVoltage / batteryVoltage;
  const parallelStrings = Math.ceil(totalBatteries / batteriesInSeries);
  
  if (batteriesInSeries === 1 && parallelStrings === 1) {
    return 'Single Battery';
  } else if (parallelStrings === 1) {
    return `${batteriesInSeries}S (Series)`;
  } else if (batteriesInSeries === 1) {
    return `${parallelStrings}P (Parallel)`;
  }
  return `${batteriesInSeries}S${parallelStrings}P`;
}

// Main calculation function
export function calculateSolarSystem(
  appliances: Appliance[],
  config: SystemConfig
): CalculationResult {
  // Get location data
  const province = PROVINCES[config.province];
  const district = province.districts[config.districtIndex];
  const psh = config.customPsh || district.psh;
  const isHotRegion = district.isHotRegion;

  // Get component specs
  const batterySpec = BATTERY_SPECS[config.batteryType];
  const panelSpec = PANEL_SPECS[config.panelType];
  const controllerSpec = CONTROLLER_SPECS[config.controllerType];
  const inverterSpec = INVERTER_SPECS[config.inverterType];

  // Filter enabled appliances
  const enabledAppliances = appliances.filter(a => a.enabled);

  // Calculate DC and AC loads separately
  let totalDailyWhDC = 0;
  let totalDailyWhAC = 0;
  let nightTimeWhDC = 0; // Night-time DC usage (for battery)
  let nightTimeWhAC = 0; // Night-time AC usage (for battery)
  let peakLoadDC = 0;
  let peakLoadAC = 0;

  for (const appliance of enabledAppliances) {
    const dailyWh = appliance.watts * appliance.quantity * appliance.hoursPerDay;
    const nightWh = appliance.watts * appliance.quantity * appliance.nightHours;
    const peakW = appliance.watts * appliance.quantity;
    
    if (appliance.isAC) {
      totalDailyWhAC += dailyWh;
      nightTimeWhAC += nightWh;
      peakLoadAC += peakW;
    } else {
      totalDailyWhDC += dailyWh;
      nightTimeWhDC += nightWh;
      peakLoadDC += peakW;
    }
  }

  // Apply inverter loss factor for AC loads (20% loss)
  const needsInverter = config.systemMode !== 'dc' && peakLoadAC > 0;
  const inverterLossFactor = needsInverter ? INVERTER_LOSS_FACTOR : 1.0;
  const adjustedACWh = totalDailyWhAC * inverterLossFactor;
  
  // Total daily consumption (what the system needs to produce - for SOLAR sizing)
  const totalDailyWh = totalDailyWhDC + adjustedACWh;
  const rawDailyWh = totalDailyWhDC + totalDailyWhAC; // Before inverter loss adjustment
  const totalPeakLoad = peakLoadDC + peakLoadAC;

  // NIGHT-TIME consumption (for BATTERY sizing - this is the key fix!)
  // Battery only needs to power night-time loads, not daytime loads
  const adjustedNightACWh = nightTimeWhAC * inverterLossFactor;
  const nightTimeWh = nightTimeWhDC + adjustedNightACWh;

  // Determine system voltage - enforce 12V for Tall Tubular batteries
  const autoVoltage = getRecommendedVoltage(rawDailyWh);
  let recommendedVoltage = config.useAutoVoltage ? autoVoltage : config.systemVoltage;
  if (config.batteryType === 'tall-tubular') {
    recommendedVoltage = 12;
  }

  // ============================================
  // SOLAR PANEL CALCULATION
  // Formula: (Total Wh / PSH) × 1.25 (or / 0.8)
  // ============================================
  const solarWattsRaw = totalDailyWh / psh; // e.g., 1344 / 5 = 268.8W
  const solarWattsRequired = solarWattsRaw * DUST_HEAT_FACTOR; // e.g., 268.8 × 1.25 = 336W sized
  
  // Find suitable panel - prefer single larger panel
  const recommendedPanelWatts = findNextStandardSize(solarWattsRequired, STANDARD_PANEL_SIZES);
  
  // Calculate panel count and configuration
  let panelWattage = recommendedPanelWatts;
  let panelCount = 1;
  
  // For larger systems, might need multiple panels
  if (solarWattsRequired > STANDARD_PANEL_SIZES[STANDARD_PANEL_SIZES.length - 1]) {
    panelWattage = 400; // Use 400W panels for large systems
    panelCount = Math.ceil(solarWattsRequired / panelWattage);
  }
  
  const actualSolarWatts = panelCount * panelWattage;
  
  // Expected daily generation: Panel Watts × PSH × 0.8
  const expectedDailyGeneration = actualSolarWatts * psh * EFFICIENCY_FACTOR;
  const generationSurplus = expectedDailyGeneration - rawDailyWh;

  // ============================================
  // BATTERY CALCULATION
  // Formula: Ah = (Night-time Wh / Voltage) / DoD
  // KEY: Battery is sized for NIGHT-TIME usage only!
  // During daytime, appliances run directly from solar panels.
  // ============================================
  const rawNightTimeWh = nightTimeWhDC + nightTimeWhAC; // Before inverter loss adjustment
  const baseAh = nightTimeWh / recommendedVoltage; // e.g., 672 / 12 = 56 Ah (only night usage)
  const batteryAhRequired = baseAh / batterySpec.dod; // e.g., 56 / 0.50 = 112 Ah
  
  // For multi-day autonomy (multiply required Ah by days)
  const batteryAhWithAutonomy = batteryAhRequired * config.autonomyDays;
  
  // Find suitable battery size
  const recommendedBatteryAh = findNextStandardSize(batteryAhWithAutonomy, STANDARD_BATTERY_SIZES);
  
  // Calculate total and usable capacity
  const batteryTotalWh = recommendedBatteryAh * recommendedVoltage; // e.g., 200 × 12 = 2400 Wh
  const batteryUsableWh = batteryTotalWh * batterySpec.dod; // e.g., 2400 × 0.50 = 1200 Wh
  
  // Calculate battery count based on system voltage
  const batteriesInSeries = recommendedVoltage / 12; // Assuming 12V batteries
  const parallelStrings = Math.ceil(batteryAhWithAutonomy / recommendedBatteryAh);
  const batteryCount = Math.max(batteriesInSeries, batteriesInSeries * parallelStrings);
  const batteryConfig = getBatteryConfig(batteryCount, recommendedVoltage);

  // ============================================
  // DOD Health Modeling (based on OffGridTrailers insight)
  // ============================================
  const actualDod = batteryTotalWh === 0 ? 0 : Math.min((nightTimeWh / batteryUsableWh) || 0, 1);
  let dodStatus: 'safe' | 'high' | 'critical' = 'safe';
  if (actualDod > batterySpec.dod) {
    dodStatus = 'critical';
  } else if (batterySpec.dodSafeFloor !== undefined && actualDod > batterySpec.dodSafeFloor) {
    dodStatus = 'high';
  }

  const effectiveCycleLife = batterySpec.cycleLifeAtRated
    ? Math.max(Math.round(batterySpec.cycleLifeAtRated * (batterySpec.dod / Math.max(actualDod, 0.15))), 300)
    : 0;

  // ============================================
  // CONTROLLER CALCULATION
  // Formula: Amps = (Panel Watts / System Voltage) × 1.25
  // ============================================
  const controllerAmpsRaw = actualSolarWatts / recommendedVoltage; // e.g., 300W / 12V = 25A
  const controllerAmpsWithSafety = controllerAmpsRaw * CONTROLLER_SAFETY_FACTOR; // e.g., 25 × 1.25 = 31.25A
  const controllerAmps = findNextStandardSize(controllerAmpsWithSafety, STANDARD_CONTROLLER_SIZES);

  // ============================================
  // INVERTER CALCULATION
  // Formula: Inverter Watts = Peak AC Load × 1.25
  // ============================================
  const inverterWattsRaw = peakLoadAC * INVERTER_SAFETY_FACTOR;
  const inverterWatts = needsInverter 
    ? findNextStandardSize(inverterWattsRaw, STANDARD_INVERTER_SIZES) 
    : 0;

  // ============================================
  // WIRE RECOMMENDATIONS
  // ============================================
  const wireRecommendations: WireRecommendation[] = [];

  // Solar to Controller
  const solarCurrent = actualSolarWatts / recommendedVoltage;
  const solarWire = getWireGauge(solarCurrent * 1.25);
  wireRecommendations.push({
    component: 'Solar Panels → Controller',
    current: Math.round(solarCurrent * 10) / 10,
    distance: '< 10ft: 10 AWG (6mm²), 15-20ft: 8 AWG (10mm²)',
    awg: solarWire.awg,
    mmSquared: solarWire.mmSq,
    notes: 'Use UV-resistant outdoor cable'
  });

  // Controller to Battery
  const batteryWire = getWireGauge(controllerAmps);
  wireRecommendations.push({
    component: 'Controller → Battery',
    current: controllerAmps,
    distance: 'Keep < 1m (3 feet)',
    awg: batteryWire.awg,
    mmSquared: batteryWire.mmSq,
    notes: 'Keep as short as possible'
  });

  // Battery to Inverter (if needed)
  if (needsInverter) {
    const inverterCurrent = inverterWatts / recommendedVoltage;
    const inverterWire = getWireGauge(inverterCurrent * 1.25);
    wireRecommendations.push({
      component: 'Battery → Inverter',
      current: Math.round(inverterCurrent * 10) / 10,
      distance: '< 0.5m (very short)',
      awg: inverterWire.awg,
      mmSquared: inverterWire.mmSq,
      notes: 'Heavy gauge required for high current'
    });
  }

  // DC Load wiring
  if (peakLoadDC > 0) {
    const dcLoadCurrent = peakLoadDC / recommendedVoltage;
    const dcWire = getWireGauge(dcLoadCurrent * 1.25);
    wireRecommendations.push({
      component: 'DC Distribution',
      current: Math.round(dcLoadCurrent * 10) / 10,
      distance: '5-15m',
      awg: dcWire.awg,
      mmSquared: dcWire.mmSq,
      notes: 'Separate circuits for lighting/fans'
    });
  }

  // Fuse recommendation: Next standard fuse size above raw current
  const STANDARD_FUSE_SIZES = [5, 10, 15, 20, 25, 30, 35, 40, 50, 60, 80, 100];
  const fuseCurrent = findNextStandardSize(solarCurrent * 1.1, STANDARD_FUSE_SIZES);

  // Battery fuse for inverter (if applicable)
  const batteryFuseCurrent = needsInverter
    ? findNextStandardSize((inverterWatts / recommendedVoltage) * 1.25, STANDARD_FUSE_SIZES)
    : undefined;

  return {
    // Load Analysis
    totalDailyWhDC,
    totalDailyWhAC,
    totalDailyWh,
    rawDailyWh,
    nightTimeWh,
    rawNightTimeWh,
    peakLoadDC,
    peakLoadAC,
    totalPeakLoad,
    
    // System Configuration
    recommendedVoltage,
    selectedPsh: psh,
    isHotRegion,
    
    // Factors Applied
    inverterLossFactor: needsInverter ? inverterLossFactor : 1.0,
    dustHeatFactor: DUST_HEAT_FACTOR,
    
    // Solar Panels
    solarWattsRaw,
    solarWattsRequired,
    panelCount,
    panelWattage,
    actualSolarWatts,
    expectedDailyGeneration,
    generationSurplus,
    panelSpec,
    
    // Battery
    baseAh,
    batteryAhRequired,
    batteryAhWithAutonomy,
    batteryCount,
    batteryAh: recommendedBatteryAh,
    batteryTotalWh,
    batteryUsableWh,
    batteryConfig,
    batterySpec,
    actualDod,
    dodStatus,
    effectiveCycleLife,
    
    // Controller
    controllerAmpsRaw,
    controllerAmpsWithSafety,
    controllerAmps,
    controllerSpec,
    
    // Inverter
    inverterWattsRaw,
    inverterWatts,
    inverterSpec,
    needsInverter,
    
    // Wiring
          wireRecommendations,
    fuseCurrent,
    batteryFuseCurrent,
    fuseNote: 'Always round up to next standard fuse size (NEC 690.9)'
  };
}



// Generate shopping list
export function generateShoppingList(result: CalculationResult): string[] {
  const items: string[] = [];
  
  if (result.panelCount === 1) {
    items.push(`1× ${result.actualSolarWatts}W ${result.panelSpec.name} Solar Panel`);
  } else {
    items.push(`${result.panelCount}× ${result.panelWattage}W ${result.panelSpec.name} Solar Panels (${result.actualSolarWatts}W total)`);
  }
  
  if (result.batteryCount === 1) {
    items.push(`1× ${result.batteryAh}Ah ${result.batterySpec.name} Battery (12V)`);
  } else {
    items.push(`${result.batteryCount}× ${result.batteryAh}Ah ${result.batterySpec.name} Batteries (${result.batteryConfig})`);
  }
  
  items.push(`1× ${result.controllerAmps}A ${result.controllerSpec.name} Charge Controller`);
  
  if (result.needsInverter) {
    const kva = result.inverterWatts >= 1000 
      ? `${(result.inverterWatts / 1000).toFixed(1)}kVA` 
      : `${result.inverterWatts}W`;
    items.push(`1× ${kva} ${result.inverterSpec.name} Inverter`);
  }
  
  // Wiring
  for (const wire of result.wireRecommendations) {
    items.push(`${wire.mmSquared}mm² (${wire.awg} AWG) cable for ${wire.component}`);
  }
  
  // Fuse
  items.push(`${result.fuseCurrent}A Fuse (between panels and controller)`);
  
  items.push('MC4 Connectors');
  items.push('Mounting structure for panels');
  items.push('Battery rack/enclosure');
  
  return items;
}
