import { Province, ProvinceData, BatterySpec, PanelSpec, ControllerSpec, InverterSpec } from '../types';

export const PROVINCES: Record<Province, ProvinceData> = {
  punjab: {
    name: 'Punjab',
    districts: [
      { name: 'Lahore', psh: 5.2, isHotRegion: false },
      { name: 'Multan', psh: 5.8, isHotRegion: true },
      { name: 'Faisalabad', psh: 5.4, isHotRegion: false },
      { name: 'Rawalpindi', psh: 4.8, isHotRegion: false },
      { name: 'Bahawalpur', psh: 5.9, isHotRegion: true },
      { name: 'Gujranwala', psh: 5.2, isHotRegion: false },
      { name: 'Sialkot', psh: 5.0, isHotRegion: false },
      { name: 'Sargodha', psh: 5.3, isHotRegion: false },
      { name: 'Rahim Yar Khan', psh: 5.8, isHotRegion: true },
      { name: 'Sahiwal', psh: 5.4, isHotRegion: false },
      { name: 'Dera Ghazi Khan', psh: 5.7, isHotRegion: true },
      { name: 'Sheikhupura', psh: 5.2, isHotRegion: false },
      { name: 'Jhang', psh: 5.4, isHotRegion: false },
      { name: 'Kasur', psh: 5.2, isHotRegion: false },
      { name: 'Okara', psh: 5.3, isHotRegion: false },
    ]
  },
  sindh: {
    name: 'Sindh',
    districts: [
      { name: 'Karachi', psh: 5.5, isHotRegion: true },
      { name: 'Hyderabad', psh: 5.6, isHotRegion: true },
      { name: 'Sukkur', psh: 5.8, isHotRegion: true },
      { name: 'Larkana', psh: 5.7, isHotRegion: true },
      { name: 'Nawabshah', psh: 5.6, isHotRegion: true },
      { name: 'Mirpur Khas', psh: 5.5, isHotRegion: true },
      { name: 'Jacobabad', psh: 6.0, isHotRegion: true },
      { name: 'Shikarpur', psh: 5.8, isHotRegion: true },
      { name: 'Khairpur', psh: 5.7, isHotRegion: true },
      { name: 'Thatta', psh: 5.4, isHotRegion: true },
      { name: 'Dadu', psh: 5.6, isHotRegion: true },
      { name: 'Tharparkar', psh: 6.2, isHotRegion: true },
    ]
  },
  kp: {
    name: 'Khyber Pakhtunkhwa',
    districts: [
      { name: 'Peshawar', psh: 5.3, isHotRegion: false },
      { name: 'Mardan', psh: 5.1, isHotRegion: false },
      { name: 'Abbottabad', psh: 4.5, isHotRegion: false },
      { name: 'Swat', psh: 4.3, isHotRegion: false },
      { name: 'Kohat', psh: 5.2, isHotRegion: false },
      { name: 'Dera Ismail Khan', psh: 5.6, isHotRegion: true },
      { name: 'Bannu', psh: 5.4, isHotRegion: false },
      { name: 'Mansehra', psh: 4.4, isHotRegion: false },
      { name: 'Nowshera', psh: 5.2, isHotRegion: false },
      { name: 'Chitral', psh: 4.2, isHotRegion: false },
      { name: 'Dir', psh: 4.3, isHotRegion: false },
      { name: 'Haripur', psh: 4.6, isHotRegion: false },
    ]
  },
  balochistan: {
    name: 'Balochistan',
    districts: [
      { name: 'Quetta', psh: 6.0, isHotRegion: false },
      { name: 'Gwadar', psh: 6.2, isHotRegion: true },
      { name: 'Turbat', psh: 6.5, isHotRegion: true },
      { name: 'Khuzdar', psh: 6.3, isHotRegion: true },
      { name: 'Sibi', psh: 6.4, isHotRegion: true },
      { name: 'Zhob', psh: 5.8, isHotRegion: false },
      { name: 'Loralai', psh: 5.9, isHotRegion: false },
      { name: 'Chaman', psh: 6.0, isHotRegion: false },
      { name: 'Hub', psh: 5.8, isHotRegion: true },
      { name: 'Lasbela', psh: 6.1, isHotRegion: true },
      { name: 'Panjgur', psh: 6.4, isHotRegion: true },
      { name: 'Dalbandin', psh: 6.5, isHotRegion: true },
    ]
  },
  gb: {
    name: 'Gilgit-Baltistan',
    districts: [
      { name: 'Gilgit', psh: 4.2, isHotRegion: false },
      { name: 'Skardu', psh: 4.0, isHotRegion: false },
      { name: 'Hunza', psh: 4.1, isHotRegion: false },
      { name: 'Nagar', psh: 4.0, isHotRegion: false },
      { name: 'Ghanche', psh: 3.8, isHotRegion: false },
      { name: 'Astore', psh: 4.0, isHotRegion: false },
      { name: 'Diamer', psh: 4.3, isHotRegion: false },
      { name: 'Ghizer', psh: 4.1, isHotRegion: false },
      { name: 'Shigar', psh: 3.9, isHotRegion: false },
      { name: 'Kharmang', psh: 3.8, isHotRegion: false },
    ]
  },
  ajk: {
    name: 'Azad Jammu & Kashmir',
    districts: [
      { name: 'Muzaffarabad', psh: 4.3, isHotRegion: false },
      { name: 'Mirpur', psh: 4.8, isHotRegion: false },
      { name: 'Kotli', psh: 4.5, isHotRegion: false },
      { name: 'Rawalakot', psh: 4.2, isHotRegion: false },
      { name: 'Bagh', psh: 4.1, isHotRegion: false },
      { name: 'Bhimber', psh: 4.7, isHotRegion: false },
      { name: 'Neelum', psh: 3.9, isHotRegion: false },
      { name: 'Sudhanoti', psh: 4.4, isHotRegion: false },
      { name: 'Hattian', psh: 4.2, isHotRegion: false },
      { name: 'Haveli', psh: 4.3, isHotRegion: false },
    ]
  }
};

export const BATTERY_SPECS: Record<string, BatterySpec> = {
  'tall-tubular': {
    type: 'tall-tubular',
    name: 'Tall Tubular',
    icon: '🌊',
    dod: 0.50,
    dodSafeFloor: 0.35,
    efficiency: 0.78,
    efficiencyFactor: 1.25,
    cycles: '1,200 - 1,500',
    cycleLifeAtRated: 1400,
    lifespan: '3-5 Years',
    tempTolerance: 'Excellent (handles 45°C+)',
    brands: ['Phoenix TX-1800', 'Osaka TA-1800', 'AGS Washi', 'Volta TA-1850', 'Exide 6LMS200'],
    pricePerAh: 180, // PKR per Ah
    description: 'Most popular in Pakistan. Handles high temperatures and frequent power cuts well.'
  },
  'sodium-ion': {
    type: 'sodium-ion',
    name: 'Sodium-Ion',
    icon: '🧂',
    dod: 0.90,
    dodSafeFloor: 0.60,
    efficiency: 0.91,
    efficiencyFactor: 1.10,
    cycles: '3,000 - 5,000',
    cycleLifeAtRated: 4200,
    lifespan: '8-12 Years',
    tempTolerance: 'Excellent (safer in extreme heat)',
    brands: ['BYD', 'CATL', 'HiNa Battery', 'Faradion'],
    pricePerAh: 350, // PKR per Ah
    description: 'Emerging technology. Safer than Lithium, works better in extreme heat, no thermal runaway risk.'
  },
  'lithium': {
    type: 'lithium',
    name: 'Lithium LiFePO4',
    icon: '🔋',
    dod: 0.85,
    dodSafeFloor: 0.20,
    efficiency: 0.96,
    efficiencyFactor: 1.10,
    cycles: '4,000 - 6,000',
    cycleLifeAtRated: 5000,
    lifespan: '10+ Years',
    tempTolerance: 'Good (needs BMS for heat)',
    brands: ['Tesla Powerwall', 'Pylontech US3000', 'Felicity', 'Growatt ARK', 'Narada'],
    pricePerAh: 450, // PKR per Ah
    description: 'Premium option with highest efficiency. Requires Battery Management System (BMS).'
  }
};

export const PANEL_SPECS: Record<string, PanelSpec> = {
  'monocrystalline': {
    type: 'monocrystalline',
    name: 'Monocrystalline',
    efficiency: 0.21,
    tempCoefficient: -0.35,
    pricePerWatt: 55, // PKR per Watt
    brands: ['JA Solar', 'Longi', 'Canadian Solar', 'Jinko', 'Trina']
  },
  'polycrystalline': {
    type: 'polycrystalline',
    name: 'Polycrystalline',
    efficiency: 0.17,
    tempCoefficient: -0.40,
    pricePerWatt: 45, // PKR per Watt
    brands: ['Risen', 'Yingli', 'Hanwha', 'Talesun']
  },
  'bifacial': {
    type: 'bifacial',
    name: 'Bifacial',
    efficiency: 0.23,
    tempCoefficient: -0.32,
    pricePerWatt: 70, // PKR per Watt
    brands: ['LONGi Hi-MO', 'JA Solar', 'Trina Vertex', 'Canadian BiHiKu']
  }
};

export const CONTROLLER_SPECS: Record<string, ControllerSpec> = {
  'pwm': {
    type: 'pwm',
    name: 'PWM Controller',
    efficiency: 0.75,
    pricePerAmp: 250 // PKR per Amp
  },
  'mppt': {
    type: 'mppt',
    name: 'MPPT Controller',
    efficiency: 0.96,
    pricePerAmp: 800 // PKR per Amp
  }
};

export const INVERTER_SPECS: Record<string, InverterSpec> = {
  'pure-sine': {
    type: 'pure-sine',
    name: 'Pure Sine Wave',
    efficiency: 0.92,
    pricePerWatt: 25, // PKR per Watt
    description: 'Best for sensitive electronics, motors, and all AC appliances.'
  },
  'modified-sine': {
    type: 'modified-sine',
    name: 'Modified Sine Wave',
    efficiency: 0.85,
    pricePerWatt: 15, // PKR per Watt
    description: 'Budget option. OK for lights/fans but not for motors or electronics.'
  },
  'hybrid': {
    type: 'hybrid',
    name: 'Hybrid Inverter',
    efficiency: 0.94,
    pricePerWatt: 35, // PKR per Watt
    description: 'All-in-one: Inverter + Charge Controller + Grid-tie capability.'
  }
};

// Standard battery sizes available in Pakistan
export const STANDARD_BATTERY_SIZES = [100, 150, 180, 200, 220, 250, 280];

// Standard panel sizes available in Pakistan
export const STANDARD_PANEL_SIZES = [100, 150, 200, 250, 300, 330, 350, 400, 430, 450, 500, 550, 600, 650];

// Standard controller ratings (Amps)
export const STANDARD_CONTROLLER_SIZES = [10, 20, 30, 40, 50, 60, 80, 100];

// Standard inverter sizes (Watts)
export const STANDARD_INVERTER_SIZES = [500, 800, 1000, 1500, 2000, 3000, 4000, 5000, 6000, 8000, 10000];

// Wire gauge recommendations tailored to Pakistani cable labels
export const WIRE_GAUGE_TABLE = [
  { maxAmps: 7, awg: 18, mmSq: 0.5, pakLabel: '23/76', resistance: 20.9 },
  { maxAmps: 12, awg: 17, mmSq: 0.75, pakLabel: '29/76', resistance: 13.2 },
  { maxAmps: 15, awg: 16, mmSq: 1.0, pakLabel: '40/76', resistance: 8.3 },
  { maxAmps: 18, awg: 15, mmSq: 1.5, pakLabel: '70/76 or 7/29', resistance: 5.5 },
  { maxAmps: 25, awg: 14, mmSq: 2.5, pakLabel: '110/76 or 7/36', resistance: 3.3 },
  { maxAmps: 35, awg: 12, mmSq: 4.0, pakLabel: '7/44', resistance: 2.1 },
  { maxAmps: 50, awg: 10, mmSq: 6.0, pakLabel: '162/76', resistance: 1.4 },
  { maxAmps: 70, awg: 8, mmSq: 10.0, pakLabel: '7/52', resistance: 0.9 },
  { maxAmps: 90, awg: 6, mmSq: 16.0, pakLabel: '210/76', resistance: 0.56 },
  { maxAmps: 120, awg: 4, mmSq: 25.0, pakLabel: '250/76', resistance: 0.36 },
  { maxAmps: 160, awg: 2, mmSq: 35.0, pakLabel: '325/76', resistance: 0.26 },
  { maxAmps: 200, awg: 1, mmSq: 50.0, pakLabel: '400/76', resistance: 0.18 },
  { maxAmps: 260, awg: 0, mmSq: 70.0, pakLabel: '500/76', resistance: 0.13 },
];

// Common appliances in Pakistan
export const APPLIANCE_PRESETS = [
  // Lighting
  { name: 'LED Bulb (9W)', watts: 9, isAC: true },
  { name: 'LED Tube Light', watts: 18, isAC: true },
  { name: 'Energy Saver', watts: 25, isAC: true },
  { name: 'DC LED Bulb (12V)', watts: 7, isAC: false },
  { name: 'DC LED Strip (12V)', watts: 12, isAC: false },
  
  // Fans
  { name: 'Ceiling Fan', watts: 75, isAC: true },
  { name: 'Pedestal Fan', watts: 55, isAC: true },
  { name: 'DC Ceiling Fan (12V)', watts: 25, isAC: false },
  { name: 'DC Table Fan (12V)', watts: 15, isAC: false },
  { name: 'Exhaust Fan', watts: 40, isAC: true },
  
  // Entertainment
  { name: 'LED TV (32")', watts: 50, isAC: true },
  { name: 'LED TV (42")', watts: 80, isAC: true },
  { name: 'LED TV (55")', watts: 120, isAC: true },
  { name: 'Dish Receiver', watts: 25, isAC: true },
  { name: 'WiFi Router', watts: 15, isAC: true },
  { name: 'Mobile Charger', watts: 10, isAC: true },
  { name: 'Laptop', watts: 65, isAC: true },
  { name: 'Desktop Computer', watts: 200, isAC: true },
  
  // Kitchen
  { name: 'Refrigerator (Small)', watts: 100, isAC: true },
  { name: 'Refrigerator (Medium)', watts: 150, isAC: true },
  { name: 'Refrigerator (Large)', watts: 250, isAC: true },
  { name: 'Deep Freezer', watts: 200, isAC: true },
  { name: 'Water Dispenser', watts: 100, isAC: true },
  { name: 'Microwave', watts: 1000, isAC: true },
  { name: 'Electric Kettle', watts: 1500, isAC: true },
  { name: 'Blender/Juicer', watts: 350, isAC: true },
  { name: 'Roti Maker', watts: 900, isAC: true },
  
  // Cooling/Heating
  { name: 'Room Cooler', watts: 200, isAC: true },
  { name: 'AC (1 Ton Inverter)', watts: 1000, isAC: true },
  { name: 'AC (1.5 Ton Inverter)', watts: 1500, isAC: true },
  { name: 'AC (2 Ton Inverter)', watts: 2000, isAC: true },
  { name: 'Room Heater', watts: 1500, isAC: true },
  { name: 'Geyser (Electric)', watts: 2000, isAC: true },
  
  // Laundry
  { name: 'Washing Machine (Semi)', watts: 400, isAC: true },
  { name: 'Washing Machine (Auto)', watts: 500, isAC: true },
  { name: 'Iron', watts: 1000, isAC: true },
  
  // Other
  { name: 'Water Pump (0.5 HP)', watts: 400, isAC: true },
  { name: 'Water Pump (1 HP)', watts: 750, isAC: true },
  { name: 'Sewing Machine', watts: 100, isAC: true },
  { name: 'Security Camera (per cam)', watts: 10, isAC: false },
];
