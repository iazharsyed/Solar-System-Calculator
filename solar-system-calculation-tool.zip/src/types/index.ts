export type UsagePeriod = 'day' | 'night' | 'both';

export interface Appliance {
  id: string;
  name: string;
  watts: number;
  quantity: number;
  hoursPerDay: number; // Total hours of usage per day
  nightHours: number; // Hours used at night (for battery calculation)
  usagePeriod: UsagePeriod; // When is this appliance primarily used?
  isAC: boolean; // true for AC appliances, false for DC
  enabled: boolean; // checkbox to include/exclude
}

export type Province = 'punjab' | 'sindh' | 'kp' | 'balochistan' | 'gb' | 'ajk';

export interface District {
  name: string;
  psh: number; // Peak Sun Hours
  isHotRegion: boolean; // For temperature factor
}

export interface ProvinceData {
  name: string;
  districts: District[];
}

export type SystemMode = 'dc' | 'ac' | 'hybrid';

export type BatteryType = 'tall-tubular' | 'sodium-ion' | 'lithium';

export interface BatterySpec {
  type: BatteryType;
  name: string;
  icon: string;
  dod: number; // Recommended Depth of Discharge (fraction)
  dodSafeFloor?: number; // Lowest practical DoD for cycling gains
  efficiency: number; // Charging efficiency
  efficiencyFactor: number; // Multiplier for losses
  cycles: string;
  cycleLifeAtRated: number; // Numeric cycle life at recommended DoD
  lifespan: string;
  tempTolerance: string;
  brands: string[];
  pricePerAh: number; // PKR per Ah
  description: string;
}

export type PanelType = 'monocrystalline' | 'polycrystalline' | 'bifacial';

export interface PanelSpec {
  type: PanelType;
  name: string;
  efficiency: number;
  tempCoefficient: number;
  pricePerWatt: number;
  brands: string[];
}

export type ControllerType = 'pwm' | 'mppt';

export interface ControllerSpec {
  type: ControllerType;
  name: string;
  efficiency: number;
  pricePerAmp: number;
}

export type InverterType = 'pure-sine' | 'modified-sine' | 'hybrid';

export interface InverterSpec {
  type: InverterType;
  name: string;
  efficiency: number;
  pricePerWatt: number;
  description: string;
}

export type SystemVoltage = 12 | 24 | 48;

export interface SystemConfig {
  province: Province;
  districtIndex: number;
  systemMode: SystemMode;
  batteryType: BatteryType;
  panelType: PanelType;
  controllerType: ControllerType;
  inverterType: InverterType;
  autonomyDays: number;
  customPsh?: number;
  systemVoltage: SystemVoltage; // Manual voltage selection
  useAutoVoltage: boolean; // Toggle between auto and manual
}

export interface WireRecommendation {
  component: string;
  current: number;
  distance: string;
  awg: number;
  mmSquared: number;
  pakLabel?: string;
  notes: string;
}

export interface CalculationResult {
  // Load Analysis
  totalDailyWhDC: number;
  totalDailyWhAC: number;
  totalDailyWh: number; // After inverter loss adjustment
  rawDailyWh: number; // Before inverter loss adjustment (actual usage)
  nightTimeWh: number; // Night-time consumption (for battery sizing)
  rawNightTimeWh: number; // Night-time before inverter loss
  peakLoadDC: number;
  peakLoadAC: number;
  totalPeakLoad: number;
  
  // System Configuration
  recommendedVoltage: number;
  selectedPsh: number;
  isHotRegion: boolean;
  
  // Factors Applied
  inverterLossFactor: number;
  dustHeatFactor: number; // Combined 25% factor for dust and heat
  
  // Solar Panels (CORRECTED)
  solarWattsRaw: number; // Total Wh / PSH (before factor)
  solarWattsRequired: number; // After dust/heat factor
  panelCount: number;
  panelWattage: number;
  actualSolarWatts: number; // Final panel wattage
  expectedDailyGeneration: number; // Panel Watts × PSH × 0.8
  generationSurplus: number; // Generation - Usage (positive = good)
  panelSpec: PanelSpec;
  
  // Battery (CORRECTED)
  baseAh: number; // Total Wh / Voltage
  batteryAhRequired: number; // After DoD applied
  batteryAhWithAutonomy: number; // With autonomy days
  batteryCount: number;
  batteryAh: number;
  batteryTotalWh: number; // Ah × Voltage (total storage)
  batteryUsableWh: number; // Total × DoD (safe backup)
  batteryConfig: string; // e.g., "2S2P"
  batterySpec: BatterySpec;
  actualDod: number; // Actual depth of discharge used each night (0-1)
  dodStatus: 'safe' | 'high' | 'critical';
  effectiveCycleLife: number; // Estimated cycles at actual DoD
  
  // Controller (CORRECTED)
  controllerAmpsRaw: number; // Before safety factor
  controllerAmpsWithSafety: number; // After 1.25 factor
  controllerAmps: number; // Final standard size
  controllerSpec: ControllerSpec;
  
  // Inverter
  inverterWattsRaw: number;
  inverterWatts: number;
  inverterSpec: InverterSpec;
  needsInverter: boolean;
  
  // Wiring & Protection
  wireRecommendations: WireRecommendation[];
  fuseCurrent: number; // Solar fuse size
  batteryFuseCurrent?: number; // Battery/inverter fuse
  fuseNote?: string;
}

export interface ShoppingListItem {
  category: string;
  item: string;
  quantity: number;
  unit: string;
  specification: string;
}
