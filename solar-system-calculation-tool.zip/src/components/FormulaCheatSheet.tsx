import { useState } from 'react';
import { BATTERY_SPECS } from '../data/pakistanData';

export default function FormulaCheatSheet() {
  const [quizAnswer, setQuizAnswer] = useState('');
  const [showSolution, setShowSolution] = useState(false);

  // Practice scenario values
  const practiceLoad = 2400; // Wh
  const practicePsh = 5; // hours
  const practiceVoltage = 24; // V
  const solarWatts = (practiceLoad / practicePsh) * 1.3;
  const controllerAmps = (solarWatts / practiceVoltage) * 1.25;

  const checkAnswer = () => {
    setShowSolution(true);
  };

  const isCorrect = parseFloat(quizAnswer) >= 32 && parseFloat(quizAnswer) <= 33;

  return (
    <div className="space-y-8">
      {/* Formula Cheat Sheet */}
      <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
        <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
          <span>📐</span> Solar Formula Cheat Sheet (Pakistan Edition)
        </h2>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white">
                <th className="text-left py-3 px-4 rounded-tl-xl">Component</th>
                <th className="text-left py-3 px-4">Goal</th>
                <th className="text-left py-3 px-4 rounded-tr-xl">Formula</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-gray-100 hover:bg-gray-50">
                <td className="py-4 px-4 font-semibold text-gray-800">⚡ Consumption</td>
                <td className="py-4 px-4 text-gray-600">Total Energy Need</td>
                <td className="py-4 px-4 font-mono text-sm bg-gray-50 rounded">Wh = Watts × Hours</td>
              </tr>
              <tr className="border-b border-gray-100 hover:bg-gray-50">
                <td className="py-4 px-4 font-semibold text-gray-800">☀️ Solar Panels</td>
                <td className="py-4 px-4 text-gray-600">Required Generation</td>
                <td className="py-4 px-4 font-mono text-sm bg-yellow-50 rounded">Array Watts = (Total Wh ÷ PSH) × 1.25</td>
              </tr>
              <tr className="border-b border-gray-100 hover:bg-gray-50">
                <td className="py-4 px-4 font-semibold text-gray-800">🔋 Battery (Tubular)</td>
                <td className="py-4 px-4 text-gray-600">Storage Capacity</td>
                <td className="py-4 px-4 font-mono text-sm bg-blue-50 rounded">Ah = (Night Wh ÷ Voltage) ÷ 0.50</td>
              </tr>
              <tr className="border-b border-gray-100 hover:bg-gray-50">
                <td className="py-4 px-4 font-semibold text-gray-800">🧂 Battery (Sodium-Ion)</td>
                <td className="py-4 px-4 text-gray-600">Storage Capacity</td>
                <td className="py-4 px-4 font-mono text-sm bg-green-50 rounded">Ah = (Night Wh ÷ Voltage) ÷ 0.90</td>
              </tr>
              <tr className="border-b border-gray-100 hover:bg-gray-50">
                <td className="py-4 px-4 font-semibold text-gray-800">🔋 Battery (Lithium)</td>
                <td className="py-4 px-4 text-gray-600">Storage Capacity</td>
                <td className="py-4 px-4 font-mono text-sm bg-purple-50 rounded">Ah = (Night Wh ÷ Voltage) ÷ 0.85</td>
              </tr>
              <tr className="border-b border-gray-100 hover:bg-gray-50">
                <td className="py-4 px-4 font-semibold text-gray-800">🕹️ Controller</td>
                <td className="py-4 px-4 text-gray-600">Current Handling</td>
                <td className="py-4 px-4 font-mono text-sm bg-indigo-50 rounded">Amps = (Array Watts ÷ System Voltage) × 1.25</td>
              </tr>
              <tr className="border-b border-gray-100 hover:bg-gray-50">
                <td className="py-4 px-4 font-semibold text-gray-800">🔌 Inverter</td>
                <td className="py-4 px-4 text-gray-600">Output Power</td>
                <td className="py-4 px-4 font-mono text-sm bg-pink-50 rounded">Inverter Watts = Peak AC Load × 1.25</td>
              </tr>
              <tr className="hover:bg-gray-50">
                <td className="py-4 px-4 font-semibold text-gray-800">🔌 AC System Loss</td>
                <td className="py-4 px-4 text-gray-600">Efficiency Adjustment</td>
                <td className="py-4 px-4 font-mono text-sm bg-orange-50 rounded">Adjusted Wh = AC Load × 1.20</td>
              </tr>
              <tr className="border-t border-gray-100 hover:bg-gray-50">
                <td className="py-4 px-4 font-semibold text-gray-800">🛡️ Fuses</td>
                <td className="py-4 px-4 text-gray-600">Protection</td>
                <td className="py-4 px-4 font-mono text-sm bg-red-50 rounded">Solar Fuse = Isc × 1.56 | Battery Fuse = Amps × 1.25</td>
              </tr>
              <tr className="border-t border-gray-100 hover:bg-gray-50">
                <td className="py-4 px-4 font-semibold text-gray-800">🔌 Wiring</td>
                <td className="py-4 px-4 text-gray-600">Voltage Drop</td>
                <td className="py-4 px-4 font-mono text-sm bg-gray-50 rounded">Vdrop = (2 × Length × Amps × Resistance) ÷ 1000</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Battery Comparison for Pakistan */}
      <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
        <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
          <span>🔋</span> Battery Comparison (Pakistan Market)
        </h2>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white">
                <th className="text-left py-3 px-4 rounded-tl-xl">Battery Type</th>
                <th className="text-center py-3 px-4">Efficiency</th>
                <th className="text-center py-3 px-4">DoD</th>
                <th className="text-center py-3 px-4">Cycles</th>
                <th className="text-center py-3 px-4">Life Span</th>
                <th className="text-left py-3 px-4 rounded-tr-xl">Best For</th>
              </tr>
            </thead>
            <tbody>
              {Object.values(BATTERY_SPECS).map((spec, idx) => (
                <tr key={idx} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-4 px-4">
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">{spec.icon}</span>
                      <div>
                        <p className="font-semibold text-gray-800">{spec.name}</p>
                        <p className="text-xs text-gray-500">{spec.brands[0]}</p>
                      </div>
                    </div>
                  </td>
                  <td className="py-4 px-4 text-center font-semibold">{(spec.efficiency * 100).toFixed(0)}%</td>
                  <td className="py-4 px-4 text-center font-semibold">{(spec.dod * 100).toFixed(0)}%</td>
                  <td className="py-4 px-4 text-center">{spec.cycles}</td>
                  <td className="py-4 px-4 text-center">{spec.lifespan}</td>
                  <td className="py-4 px-4 text-gray-600 text-xs">{spec.description}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* System Voltage Guide */}
      <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
        <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
          <span>🧠</span> Choosing Your System Voltage
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-5 bg-gradient-to-br from-green-50 to-emerald-100 rounded-xl border border-green-200">
            <div className="text-4xl font-bold text-green-600 mb-2">12V</div>
            <h4 className="font-semibold text-gray-800 mb-2">Small Systems</h4>
            <p className="text-sm text-gray-600 mb-3">Best for RVs, vans, small cabins under 1,000 Wh/day</p>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>✓ Easy to find 12V appliances</li>
              <li>✓ Simple setup</li>
              <li>⚠️ Requires thick wires for high power</li>
            </ul>
          </div>

          <div className="p-5 bg-gradient-to-br from-blue-50 to-indigo-100 rounded-xl border border-blue-200">
            <div className="text-4xl font-bold text-blue-600 mb-2">24V</div>
            <h4 className="font-semibold text-gray-800 mb-2">Medium Systems</h4>
            <p className="text-sm text-gray-600 mb-3">Ideal for homes with 1,000-3,000 Wh/day consumption</p>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>✓ Half the current of 12V</li>
              <li>✓ Thinner wires possible</li>
              <li>✓ Most common in Pakistan</li>
            </ul>
          </div>

          <div className="p-5 bg-gradient-to-br from-purple-50 to-pink-100 rounded-xl border border-purple-200">
            <div className="text-4xl font-bold text-purple-600 mb-2">48V</div>
            <h4 className="font-semibold text-gray-800 mb-2">Large Systems</h4>
            <p className="text-sm text-gray-600 mb-3">Standard for off-grid homes over 3,000 Wh/day</p>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>✓ Lowest current for heavy loads</li>
              <li>✓ Best for AC, pumps, appliances</li>
              <li>✓ Most efficient for large systems</li>
            </ul>
          </div>
        </div>
      </div>

      {/* AC vs DC Explanation */}
      <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
        <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
          <span>🔌</span> AC vs DC Systems
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-5 bg-gradient-to-br from-green-50 to-teal-100 rounded-xl border border-green-200">
            <div className="text-3xl mb-3">🔋</div>
            <h4 className="font-bold text-gray-800 mb-2">DC System (Off-Grid/Small)</h4>
            <div className="text-sm text-gray-600 mb-4">
              <p className="mb-2">Panels → Controller → Battery → DC Appliances</p>
              <p>Direct use of solar power without conversion</p>
            </div>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>✓ More efficient (no inverter loss)</li>
              <li>✓ Great for fans, lights, phones</li>
              <li>✓ Lower cost</li>
              <li>⚠️ Limited to DC appliances</li>
            </ul>
          </div>

          <div className="p-5 bg-gradient-to-br from-blue-50 to-indigo-100 rounded-xl border border-blue-200">
            <div className="text-3xl mb-3">⚡</div>
            <h4 className="font-bold text-gray-800 mb-2">AC System (Standard Home)</h4>
            <div className="text-sm text-gray-600 mb-4">
              <p className="mb-2">Panels → Controller → Battery → Inverter → 220V Appliances</p>
              <p>Converts DC to AC for standard appliances</p>
            </div>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>✓ Powers all standard appliances</li>
              <li>✓ AC, fridge, TV, washing machine</li>
              <li>⚠️ 15-20% energy loss in inverter</li>
              <li>⚠️ Higher cost</li>
            </ul>
          </div>
        </div>

        <div className="mt-6 p-4 bg-amber-50 rounded-xl border border-amber-200">
          <p className="text-amber-800 font-medium">💡 Pro Tip for Pakistan:</p>
          <p className="text-amber-700 text-sm mt-1">
            For maximum efficiency, use DC fans and DC LED lights directly from the battery during load-shedding. 
            Use the inverter only for appliances that require AC power (refrigerator, TV, washing machine).
          </p>
        </div>
      </div>

      {/* Depth of Discharge (DoD) Explainer */}
      <div className="bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50 rounded-2xl shadow-lg p-6 border border-amber-200">
        <h2 className="text-2xl font-bold text-amber-800 mb-4 flex items-center gap-2">
          <span>🧭</span> Depth of Discharge (DoD) — Why It Matters
        </h2>
        <p className="text-sm text-amber-800 mb-4">
          DoD is how much of the battery you use before recharging. A 40% DoD means you used 40% and still have 60% State of Charge (SOC) left.
          Deeper cycles = fewer total cycles over the battery’s life. These bands mirror the Off Grid Trailers guidance.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-3">
            <div className="p-3 rounded-xl bg-green-50 border border-green-200">
              <div className="flex items-center justify-between text-green-800 text-sm font-semibold">
                <span>Shallow Cycle</span>
                <span>0–30% DoD</span>
              </div>
              <div className="mt-2 h-2 rounded-full bg-green-200">
                <div className="h-2 w-1/3 rounded-full bg-green-500"></div>
              </div>
              <p className="text-xs text-green-700 mt-2">Highest cycle life. Great for Lithium/Sodium-Ion. Battery stays healthy longest.</p>
            </div>

            <div className="p-3 rounded-xl bg-blue-50 border border-blue-200">
              <div className="flex items-center justify-between text-blue-800 text-sm font-semibold">
                <span>Moderate Cycle</span>
                <span>30–60% DoD</span>
              </div>
              <div className="mt-2 h-2 rounded-full bg-blue-200">
                <div className="h-2 w-1/2 rounded-full bg-blue-500"></div>
              </div>
              <p className="text-xs text-blue-700 mt-2">Balanced for daily use. Good target for Tall Tubular (≤50%) and Lithium (≤60%).</p>
            </div>

            <div className="p-3 rounded-xl bg-red-50 border border-red-200">
              <div className="flex items-center justify-between text-red-800 text-sm font-semibold">
                <span>Deep Cycle</span>
                <span>60–100% DoD</span>
              </div>
              <div className="mt-2 h-2 rounded-full bg-red-200">
                <div className="h-2 w-full rounded-full bg-red-500"></div>
              </div>
              <p className="text-xs text-red-700 mt-2">Use sparingly. Shortens battery life quickly. If you hit this nightly, add more capacity.</p>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-white border border-amber-100 shadow-inner space-y-2 text-sm text-gray-700">
            <h4 className="font-semibold text-amber-800 flex items-center gap-2"><span>📊</span> DoD → Cycle Life Guidance</h4>
            <ul className="space-y-1 text-xs">
              <li>• <strong>Tall Tubular:</strong> Keep ≤50% DoD for best life (matches our "safe" band). Occasional 60% is OK, avoid &gt;70%.</li>
              <li>• <strong>Sodium-Ion:</strong> Comfortable up to ~80–90% DoD, but shallower (40–60%) yields far more cycles.</li>
              <li>• <strong>Lithium (LiFePO4):</strong> Rated for deep cycles, yet 20–60% DoD dramatically boosts total cycles.</li>
              <li>• Our battery card now shows <strong>nightly DoD %</strong> and warns when you exceed safe bands.</li>
            </ul>
            <div className="mt-3 p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-800">
              <strong>Rule of Thumb:</strong> If nightly DoD is in the red zone, add another battery (parallel) or reduce night load to get back into green/blue.
            </div>
            <p className="text-[11px] text-gray-500 mt-2">Note: External images from the referenced guide aren’t embedded here; this section distills the same DoD guidance into text/visual bars.</p>
          </div>
        </div>
      </div>

      {/* Practice Quiz */}
      <div className="bg-gradient-to-br from-indigo-50 to-purple-100 rounded-2xl shadow-lg p-6 border border-indigo-200">
        <h2 className="text-2xl font-bold text-indigo-800 mb-6 flex items-center gap-2">
          <span>💡</span> Practice Scenario
        </h2>

        <div className="bg-white rounded-xl p-5 mb-6">
          <h4 className="font-semibold text-gray-800 mb-3">Medium Cabin in Lahore:</h4>
          <ul className="space-y-2 text-gray-700">
            <li>• Total Daily Need: <strong>{practiceLoad} Wh</strong></li>
            <li>• Peak Sun Hours: <strong>{practicePsh} hours</strong></li>
            <li>• System Voltage: <strong>{practiceVoltage}V</strong></li>
          </ul>
        </div>

        <div className="bg-white rounded-xl p-5 mb-6">
          <p className="text-gray-800 mb-4">
            <strong>Question:</strong> If the solar array calculates to <strong>{Math.round(solarWatts)}W</strong>, 
            what is the minimum Amp rating for the Charge Controller? (Remember the 1.25 safety multiplier!)
          </p>

          <div className="flex gap-4 items-center">
            <input
              type="number"
              value={quizAnswer}
              onChange={(e) => setQuizAnswer(e.target.value)}
              placeholder="Enter Amps..."
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 w-32"
              step="0.1"
            />
            <span className="text-gray-600">Amps</span>
            <button
              onClick={checkAnswer}
              className="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition font-medium"
            >
              Check Answer
            </button>
          </div>
        </div>

        {showSolution && (
          <div className={`rounded-xl p-5 ${isCorrect ? 'bg-green-100 border border-green-300' : 'bg-amber-100 border border-amber-300'}`}>
            <h4 className={`font-bold mb-3 ${isCorrect ? 'text-green-800' : 'text-amber-800'}`}>
              {isCorrect ? '✅ Correct!' : '📝 Solution:'}
            </h4>
            <div className="space-y-2 text-gray-700">
              <p><strong>Step 1:</strong> Solar Array = ({practiceLoad} ÷ {practicePsh}) × 1.3 = {Math.round(solarWatts)}W</p>
              <p><strong>Step 2:</strong> Controller Amps = ({Math.round(solarWatts)}W ÷ {practiceVoltage}V) × 1.25</p>
              <p><strong>Step 3:</strong> = {(solarWatts / practiceVoltage).toFixed(1)}A × 1.25 = <strong>{controllerAmps.toFixed(1)}A</strong></p>
              <p className="mt-3 text-indigo-700 font-medium">
                ➡️ You would need at least a <strong>40A MPPT Controller</strong> (next standard size up)
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Pakistan-Specific Tips */}
      <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
        <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
          <span>🇵🇰</span> Pakistan-Specific Tips
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-orange-50 rounded-xl border border-orange-200">
            <h4 className="font-semibold text-orange-800 mb-2">🌡️ Hot Regions (Sindh, South Punjab)</h4>
            <p className="text-sm text-orange-700">
              Add 10% extra battery capacity for Tall Tubular batteries. Consider Sodium-Ion for better heat tolerance.
            </p>
          </div>

          <div className="p-4 bg-blue-50 rounded-xl border border-blue-200">
            <h4 className="font-semibold text-blue-800 mb-2">🏔️ Northern Areas (GB, AJK)</h4>
            <p className="text-sm text-blue-700">
              Lower PSH (4-4.5 hours). Plan for more panels or larger battery bank for cloudy days.
            </p>
          </div>

          <div className="p-4 bg-yellow-50 rounded-xl border border-yellow-200">
            <h4 className="font-semibold text-yellow-800 mb-2">🌫️ Dust Factor</h4>
            <p className="text-sm text-yellow-700">
              Pakistan's dusty environment reduces panel efficiency by 15%. Clean panels weekly for best performance.
            </p>
          </div>

          <div className="p-4 bg-green-50 rounded-xl border border-green-200">
            <h4 className="font-semibold text-green-800 mb-2">⚡ Load Shedding</h4>
            <p className="text-sm text-green-700">
              Size your battery for expected load-shedding hours. 2 days autonomy recommended for areas with frequent outages.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
