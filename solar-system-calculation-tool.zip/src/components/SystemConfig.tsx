import { SystemConfig, Province, SystemMode, SystemVoltage } from '../types';
import { PROVINCES, BATTERY_SPECS, PANEL_SPECS, CONTROLLER_SPECS, INVERTER_SPECS } from '../data/pakistanData';
import { getRecommendedVoltage } from '../utils/calculations';

interface SystemConfigProps {
  config: SystemConfig;
  onChange: (key: keyof SystemConfig, value: SystemConfig[keyof SystemConfig]) => void;
  onProvinceChange: (province: Province) => void;
  totalDailyWh: number;
}

export default function SystemConfigComponent({ config, onChange, onProvinceChange, totalDailyWh }: SystemConfigProps) {
  const selectedProvince = PROVINCES[config.province];
  const selectedDistrict = selectedProvince?.districts[config.districtIndex] || PROVINCES.punjab.districts[0];
  const recommendedVoltage = getRecommendedVoltage(totalDailyWh);

  return (
    <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
      <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2 mb-6">
        <span className="text-2xl">⚙️</span> System Configuration
      </h2>

      {/* Location Selection */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold text-gray-700 mb-4 flex items-center gap-2">
          <span>🌍</span> Location (Peak Sun Hours)
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-2">Province/Region</label>
            <select
              value={config.province}
              onChange={(e) => onProvinceChange(e.target.value as Province)}
              className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 bg-white"
            >
              {Object.entries(PROVINCES).map(([key, province]) => (
                <option key={key} value={key}>{province.name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-600 mb-2">District/City</label>
            <select
              value={config.districtIndex}
              onChange={(e) => onChange('districtIndex', Number(e.target.value))}
              className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 bg-white"
            >
              {selectedProvince.districts.map((district, idx) => (
                <option key={idx} value={idx}>
                  {district.name} ({district.psh} PSH){district.isHotRegion ? ' 🌡️' : ''}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Location Info Card */}
        <div className={`mt-4 p-4 rounded-xl ${selectedDistrict.isHotRegion ? 'bg-orange-50 border border-orange-200' : 'bg-blue-50 border border-blue-200'}`}>
          <div className="flex items-center justify-between">
            <div>
              <p className="font-semibold text-gray-800">{selectedDistrict.name}, {selectedProvince.name}</p>
              <p className="text-sm text-gray-600">Peak Sun Hours: <span className="font-bold text-emerald-600">{selectedDistrict.psh} hours/day</span></p>
            </div>
            {selectedDistrict.isHotRegion && (
              <div className="text-right">
                <span className="px-3 py-1 bg-orange-200 text-orange-800 rounded-full text-sm font-medium">
                  🌡️ Hot Region
                </span>
                <p className="text-xs text-orange-600 mt-1">+10% battery buffer applied</p>
              </div>
            )}
          </div>
        </div>

        {/* Custom PSH Override */}
        <div className="mt-4">
          <label className="block text-sm font-medium text-gray-600 mb-2">
            Custom PSH (Optional Override)
          </label>
          <input
            type="number"
            value={config.customPsh || ''}
            onChange={(e) => onChange('customPsh', e.target.value ? Number(e.target.value) : undefined)}
            placeholder={`Default: ${selectedDistrict.psh}`}
            step="0.1"
            min="2"
            max="8"
            className="w-full md:w-48 px-4 py-2 rounded-xl border border-gray-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
          />
        </div>
      </div>

      {/* System Mode Selection */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold text-gray-700 mb-4 flex items-center gap-2">
          <span>🔌</span> System Type
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { mode: 'dc' as SystemMode, icon: '🔋', title: 'DC Only', desc: 'Direct DC appliances (fans, lights)', loss: 'No inverter loss' },
            { mode: 'ac' as SystemMode, icon: '⚡', title: 'AC System', desc: 'Standard 220V appliances', loss: '~20% inverter loss' },
            { mode: 'hybrid' as SystemMode, icon: '🔄', title: 'Hybrid (AC+DC)', desc: 'Both AC and DC appliances', loss: 'Most flexible' },
          ].map((option) => (
            <button
              key={option.mode}
              onClick={() => onChange('systemMode', option.mode)}
              className={`p-4 rounded-xl border-2 transition text-left ${
                config.systemMode === option.mode
                  ? 'border-emerald-500 bg-emerald-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <div className="text-3xl mb-2">{option.icon}</div>
              <h4 className="font-semibold text-gray-800">{option.title}</h4>
              <p className="text-sm text-gray-500">{option.desc}</p>
              <p className="text-xs text-emerald-600 mt-2">{option.loss}</p>
            </button>
          ))}
        </div>
      </div>

      {/* System Voltage Selection */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold text-gray-700 mb-4 flex items-center gap-2">
          <span>⚡</span> System Voltage
        </h3>
        
        {config.batteryType === 'tall-tubular' ? (
          <div className="p-4 bg-yellow-50 border-2 border-yellow-300 rounded-xl mb-4">
            <h4 className="font-semibold text-yellow-800 mb-1">🔒 Locked to 12V</h4>
            <p className="text-sm text-yellow-700">
              Tall Tubular batteries are 12V units. System voltage is fixed to 12V for safe charging.
            </p>
          </div>
        ) : (
          <>
            {/* Auto/Manual Toggle */}
            <div className="flex items-center gap-4 mb-4">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={config.useAutoVoltage}
                  onChange={(e) => onChange('useAutoVoltage', e.target.checked)}
                  className="w-5 h-5 text-emerald-500 rounded focus:ring-emerald-500"
                />
                <span className="font-medium text-gray-700">Auto-select based on load</span>
              </label>
              {config.useAutoVoltage && (
                <span className="text-sm text-emerald-600">
                  (Recommended: {recommendedVoltage}V for {totalDailyWh.toLocaleString()} Wh)
                </span>
              )}
            </div>
          </>
        )}

        {/* Manual Voltage Selection */}
        <div className={`${config.useAutoVoltage || config.batteryType === 'tall-tubular' ? 'opacity-50 pointer-events-none' : ''}`}>
          <div className="grid grid-cols-3 gap-4">
            {([12, 24, 48] as SystemVoltage[]).map((voltage) => (
              <button
                key={voltage}
                onClick={() => onChange('systemVoltage', voltage)}
                className={`p-4 rounded-xl border-2 transition text-center ${
                  (config.useAutoVoltage && recommendedVoltage === voltage) ||
                  (!config.useAutoVoltage && config.systemVoltage === voltage)
                    ? 'border-purple-500 bg-purple-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="text-3xl font-bold text-purple-600 mb-1">{voltage}V</div>
                <p className="text-xs text-gray-600">
                  {voltage === 12 && 'Small systems (<1000Wh)'}
                  {voltage === 24 && 'Medium systems (1-3kWh)'}
                  {voltage === 48 && 'Large systems (>3kWh)'}
                </p>
                {voltage === recommendedVoltage && config.useAutoVoltage && (
                  <span className="inline-block mt-2 px-2 py-0.5 bg-purple-200 text-purple-800 text-xs rounded-full">
                    Recommended
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>
        
        {/* Voltage Guide */}
        <div className="mt-4 p-4 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl border border-indigo-200">
          <h4 className="font-semibold text-indigo-800 mb-2">📘 Voltage Guide:</h4>
          <ul className="text-sm text-indigo-700 space-y-1">
            <li>• <strong>12V:</strong> Simple setup, RVs, small cabins. Thicker wires needed for high power.</li>
            <li>• <strong>24V:</strong> Most popular in Pakistan homes. Good balance of efficiency & cost.</li>
            <li>• <strong>48V:</strong> Off-grid homes, heavy loads (AC, pumps). Thinner wires, best efficiency.</li>
          </ul>
        </div>
      </div>

      {/* Battery Selection */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold text-gray-700 mb-4 flex items-center gap-2">
          <span>🔋</span> Battery Type
        </h3>
        
        <p className="text-sm text-gray-500 mb-3">Step 1: Choose your voltage above. Step 2: Pick your battery chemistry below.</p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {Object.entries(BATTERY_SPECS).map(([key, spec]) => (
            <button
              key={key}
              onClick={() => onChange('batteryType', key as SystemConfig['batteryType'])}
              className={`p-4 rounded-xl border-2 transition text-left ${
                config.batteryType === key
                  ? 'border-emerald-500 bg-emerald-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <div className="flex items-center gap-2 mb-2">
                <span className="text-2xl">{spec.icon}</span>
                <h4 className="font-semibold text-gray-800">{spec.name}</h4>
              </div>
              <div className="space-y-1 text-sm">
                <p className="text-gray-600">DoD: <span className="font-semibold">{spec.dod * 100}%</span></p>
                <p className="text-gray-600">Cycles: <span className="font-semibold">{spec.cycles}</span></p>
                <p className="text-gray-600">Life: <span className="font-semibold">{spec.lifespan}</span></p>
                <p className="text-xs text-gray-500 mt-2">{spec.brands.slice(0, 2).join(', ')}</p>
                {key === 'tall-tubular' && (
                  <p className="text-xs font-semibold text-yellow-600 mt-2">⚠️ Locks system to 12V (battery plates are 6×2V)</p>
                )}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Panel Selection */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold text-gray-700 mb-4 flex items-center gap-2">
          <span>☀️</span> Solar Panel Type
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {Object.entries(PANEL_SPECS).map(([key, spec]) => (
            <button
              key={key}
              onClick={() => onChange('panelType', key as SystemConfig['panelType'])}
              className={`p-4 rounded-xl border-2 transition text-left ${
                config.panelType === key
                  ? 'border-yellow-500 bg-yellow-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <h4 className="font-semibold text-gray-800 mb-2">{spec.name}</h4>
              <p className="text-sm text-gray-600">Efficiency: <span className="font-semibold">{(spec.efficiency * 100).toFixed(0)}%</span></p>
              <p className="text-xs text-gray-500 mt-2">{spec.brands.slice(0, 2).join(', ')}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Controller & Inverter Selection */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <div>
          <h3 className="text-lg font-semibold text-gray-700 mb-4 flex items-center gap-2">
            <span>🕹️</span> Charge Controller
          </h3>
          <div className="space-y-3">
            {Object.entries(CONTROLLER_SPECS).map(([key, spec]) => (
              <button
                key={key}
                onClick={() => onChange('controllerType', key as SystemConfig['controllerType'])}
                className={`w-full p-4 rounded-xl border-2 transition text-left ${
                  config.controllerType === key
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <h4 className="font-semibold text-gray-800">{spec.name}</h4>
                <p className="text-sm text-gray-600">Efficiency: {(spec.efficiency * 100).toFixed(0)}%</p>
              </button>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-lg font-semibold text-gray-700 mb-4 flex items-center gap-2">
            <span>🔌</span> Inverter Type
          </h3>
          <div className="space-y-3">
            {Object.entries(INVERTER_SPECS).map(([key, spec]) => (
              <button
                key={key}
                onClick={() => onChange('inverterType', key as SystemConfig['inverterType'])}
                className={`w-full p-4 rounded-xl border-2 transition text-left ${
                  config.inverterType === key
                    ? 'border-purple-500 bg-purple-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <h4 className="font-semibold text-gray-800">{spec.name}</h4>
                <p className="text-sm text-gray-500">{spec.description}</p>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Autonomy Days */}
      <div>
        <h3 className="text-lg font-semibold text-gray-700 mb-4 flex items-center gap-2">
          <span>📅</span> Backup Days (Autonomy)
        </h3>
        <div className="flex items-center gap-4">
          <input
            type="range"
            min="1"
            max="5"
            value={config.autonomyDays}
            onChange={(e) => onChange('autonomyDays', Number(e.target.value))}
            className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-emerald-500"
          />
          <span className="text-2xl font-bold text-emerald-600 min-w-[60px]">{config.autonomyDays} day{config.autonomyDays > 1 ? 's' : ''}</span>
        </div>
        <p className="text-sm text-gray-500 mt-2">
          Number of cloudy/rainy days the batteries should last without solar charging
        </p>
      </div>
    </div>
  );
}
