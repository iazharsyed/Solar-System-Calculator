import React, { useState } from 'react';
import { Appliance, UsagePeriod } from '../types';
import { APPLIANCE_PRESETS } from '../data/pakistanData';

interface ApplianceFormProps {
  onAddAppliance: (appliance: Omit<Appliance, 'id'>) => void;
}

export default function ApplianceForm({ onAddAppliance }: ApplianceFormProps) {
  const [name, setName] = useState('');
  const [watts, setWatts] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [hoursPerDay, setHoursPerDay] = useState(4);
  const [nightHours, setNightHours] = useState(2);
  const [usagePeriod, setUsagePeriod] = useState<UsagePeriod>('both');
  const [isAC, setIsAC] = useState(true);
  const [showPresets, setShowPresets] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // Auto-adjust night hours based on usage period
  const handleUsagePeriodChange = (period: UsagePeriod) => {
    setUsagePeriod(period);
    if (period === 'day') {
      setNightHours(0);
    } else if (period === 'night') {
      setNightHours(hoursPerDay);
    } else {
      // 'both' - set night hours to half of total
      setNightHours(Math.ceil(hoursPerDay / 2));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || watts <= 0) return;
    
    onAddAppliance({
      name,
      watts,
      quantity,
      hoursPerDay,
      nightHours: usagePeriod === 'day' ? 0 : (usagePeriod === 'night' ? hoursPerDay : nightHours),
      usagePeriod,
      isAC,
      enabled: true
    });
    
    // Reset form
    setName('');
    setWatts(0);
    setQuantity(1);
    setHoursPerDay(4);
    setNightHours(2);
    setUsagePeriod('both');
    setIsAC(true);
  };

  const handlePresetSelect = (preset: typeof APPLIANCE_PRESETS[0]) => {
    // Determine default usage period based on appliance type
    let defaultPeriod: UsagePeriod = 'both';
    let defaultNightHours = 2;
    const lowerName = preset.name.toLowerCase();
    
    if (lowerName.includes('light') || lowerName.includes('led') || lowerName.includes('bulb')) {
      defaultPeriod = 'night';
      defaultNightHours = 4;
    } else if (lowerName.includes('iron') || lowerName.includes('washing')) {
      defaultPeriod = 'day';
      defaultNightHours = 0;
    } else if (lowerName.includes('refrigerator') || lowerName.includes('freezer')) {
      defaultPeriod = 'both';
      defaultNightHours = 12; // Runs 24/7, half at night
    } else if (lowerName.includes('fan')) {
      defaultPeriod = 'both';
      defaultNightHours = 6; // More at night for sleeping
    }
    
    onAddAppliance({
      name: preset.name,
      watts: preset.watts,
      quantity: 1,
      hoursPerDay: defaultPeriod === 'night' ? defaultNightHours : 4,
      nightHours: defaultNightHours,
      usagePeriod: defaultPeriod,
      isAC: preset.isAC,
      enabled: true
    });
    setShowPresets(false);
    setSearchTerm('');
  };

  const filteredPresets = APPLIANCE_PRESETS.filter(p =>
    p.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Group presets by category
  const categories = [
    { name: '💡 Lighting', items: filteredPresets.filter(p => p.name.toLowerCase().includes('led') || p.name.toLowerCase().includes('light') || p.name.toLowerCase().includes('bulb')) },
    { name: '🌀 Fans', items: filteredPresets.filter(p => p.name.toLowerCase().includes('fan')) },
    { name: '📺 Entertainment', items: filteredPresets.filter(p => ['tv', 'receiver', 'router', 'mobile', 'laptop', 'computer'].some(k => p.name.toLowerCase().includes(k))) },
    { name: '🍳 Kitchen', items: filteredPresets.filter(p => ['refrigerator', 'freezer', 'dispenser', 'microwave', 'kettle', 'blender', 'roti'].some(k => p.name.toLowerCase().includes(k))) },
    { name: '❄️ Cooling/Heating', items: filteredPresets.filter(p => ['cooler', 'ac', 'heater', 'geyser'].some(k => p.name.toLowerCase().includes(k))) },
    { name: '🧺 Laundry', items: filteredPresets.filter(p => ['washing', 'iron'].some(k => p.name.toLowerCase().includes(k))) },
    { name: '⚡ Other', items: filteredPresets.filter(p => ['pump', 'sewing', 'camera', 'exhaust'].some(k => p.name.toLowerCase().includes(k))) },
  ];

  return (
    <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
          <span className="text-2xl">⚡</span> Add Appliances
        </h2>
        <button
          type="button"
          onClick={() => setShowPresets(!showPresets)}
          className="px-4 py-2 bg-emerald-100 text-emerald-700 rounded-lg hover:bg-emerald-200 transition font-medium text-sm flex items-center gap-2"
        >
          <span>📋</span> {showPresets ? 'Hide Presets' : 'Quick Add'}
        </button>
      </div>

      {showPresets && (
        <div className="mb-6 p-4 bg-gray-50 rounded-xl border border-gray-200">
          <input
            type="text"
            placeholder="🔍 Search appliances..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 mb-4"
          />
          <div className="max-h-64 overflow-y-auto space-y-4">
            {categories.map(category => (
              category.items.length > 0 && (
                <div key={category.name}>
                  <h4 className="text-sm font-semibold text-gray-600 mb-2">{category.name}</h4>
                  <div className="flex flex-wrap gap-2">
                    {category.items.map((preset, idx) => (
                      <button
                        key={idx}
                        onClick={() => handlePresetSelect(preset)}
                        className={`px-3 py-1.5 rounded-full text-sm font-medium transition ${
                          preset.isAC 
                            ? 'bg-blue-100 text-blue-700 hover:bg-blue-200' 
                            : 'bg-green-100 text-green-700 hover:bg-green-200'
                        }`}
                      >
                        {preset.name} ({preset.watts}W)
                      </button>
                    ))}
                  </div>
                </div>
              )
            ))}
          </div>
          <div className="mt-3 flex gap-4 text-xs text-gray-500">
            <span className="flex items-center gap-1"><span className="w-3 h-3 bg-blue-200 rounded-full"></span> AC (220V)</span>
            <span className="flex items-center gap-1"><span className="w-3 h-3 bg-green-200 rounded-full"></span> DC (12V)</span>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="lg:col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-1">Appliance Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Ceiling Fan"
              className="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Power (Watts)</label>
            <input
              type="number"
              value={watts || ''}
              onChange={(e) => setWatts(Number(e.target.value))}
              placeholder="75"
              min="1"
              className="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Quantity</label>
            <input
              type="number"
              value={quantity}
              onChange={(e) => setQuantity(Number(e.target.value))}
              min="1"
              className="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
            />
          </div>
        </div>

        {/* Usage Period Selection */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Usage Period</label>
            <div className="flex gap-1">
              <button
                type="button"
                onClick={() => handleUsagePeriodChange('day')}
                className={`flex-1 py-2 px-2 rounded-lg text-sm font-medium transition ${
                  usagePeriod === 'day' 
                    ? 'bg-yellow-500 text-white' 
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                ☀️ Day
              </button>
              <button
                type="button"
                onClick={() => handleUsagePeriodChange('night')}
                className={`flex-1 py-2 px-2 rounded-lg text-sm font-medium transition ${
                  usagePeriod === 'night' 
                    ? 'bg-indigo-500 text-white' 
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                🌙 Night
              </button>
              <button
                type="button"
                onClick={() => handleUsagePeriodChange('both')}
                className={`flex-1 py-2 px-2 rounded-lg text-sm font-medium transition ${
                  usagePeriod === 'both' 
                    ? 'bg-purple-500 text-white' 
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                🔄 Both
              </button>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Total Hours/Day</label>
            <input
              type="number"
              value={hoursPerDay}
              onChange={(e) => {
                const total = Number(e.target.value);
                setHoursPerDay(total);
                if (usagePeriod === 'night') setNightHours(total);
                else if (usagePeriod === 'both') setNightHours(Math.min(nightHours, total));
              }}
              min="0.5"
              max="24"
              step="0.5"
              className="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Night Hours 🌙 <span className="text-xs text-gray-400">(for battery)</span>
            </label>
            <input
              type="number"
              value={nightHours}
              onChange={(e) => setNightHours(Math.min(Number(e.target.value), hoursPerDay))}
              min="0"
              max={hoursPerDay}
              step="0.5"
              disabled={usagePeriod === 'day'}
              className={`w-full px-4 py-2.5 rounded-lg border focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 ${
                usagePeriod === 'day' ? 'bg-gray-100 border-gray-200 text-gray-400' : 'border-gray-300'
              }`}
            />
          </div>
        </div>

        <div className="flex gap-4">
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-1">AC/DC Type</label>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setIsAC(true)}
                className={`flex-1 py-2.5 px-4 rounded-lg font-medium transition ${
                  isAC 
                    ? 'bg-blue-500 text-white' 
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                ⚡ AC (220V)
              </button>
              <button
                type="button"
                onClick={() => setIsAC(false)}
                className={`flex-1 py-2.5 px-4 rounded-lg font-medium transition ${
                  !isAC 
                    ? 'bg-green-500 text-white' 
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                🔋 DC (12V)
              </button>
            </div>
          </div>
        </div>
        
        {/* Info Box */}
        <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
          <p className="text-sm text-blue-700">
            <strong>💡 Why Night Hours?</strong> During daytime, appliances run directly from solar panels. 
            Battery is only used at night! So we size the battery based on <strong>night-time usage only</strong>.
          </p>
        </div>

        <button
          type="submit"
          disabled={!name || watts <= 0}
          className="w-full py-3 bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-xl font-semibold hover:from-emerald-600 hover:to-teal-700 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          <span className="text-xl">+</span> Add Appliance
        </button>
      </form>
    </div>
  );
}
