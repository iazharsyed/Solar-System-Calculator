import { CalculationResult, SystemConfig } from '../types';
import { PROVINCES } from '../data/pakistanData';

interface ResultsProps {
  results: CalculationResult;
  config: SystemConfig;
}

export default function Results({ results, config }: ResultsProps) {
  const province = PROVINCES[config.province];
  const district = province.districts[config.districtIndex];
  const isAC = config.systemMode === 'ac' || config.systemMode === 'hybrid';

  if (results.rawDailyWh === 0) {
    return (
      <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100 text-center">
        <div className="text-6xl mb-4">📊</div>
        <h3 className="text-lg font-semibold text-gray-700 mb-2">No Calculations Yet</h3>
        <p className="text-gray-500">Add appliances to see your solar system requirements</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Summary Header */}
      <div className="bg-gradient-to-r from-emerald-600 to-teal-700 rounded-2xl shadow-lg p-6 text-white">
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
          <span>🌞</span> Solar System Design for {district.name}, {province.name}
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <div className="bg-white/20 rounded-xl p-4">
            <p className="text-emerald-100 text-sm">Total Daily Usage</p>
            <p className="text-2xl font-bold">{results.rawDailyWh.toLocaleString()} Wh</p>
            <p className="text-xs text-emerald-200">For solar sizing</p>
          </div>
          <div className="bg-yellow-400/30 rounded-xl p-4 border-2 border-yellow-400/50">
            <p className="text-yellow-100 text-sm">🌙 Night Usage</p>
            <p className="text-2xl font-bold">{results.rawNightTimeWh.toLocaleString()} Wh</p>
            <p className="text-xs text-yellow-200">For battery sizing</p>
          </div>
          <div className="bg-white/20 rounded-xl p-4">
            <p className="text-emerald-100 text-sm">System Voltage</p>
            <p className="text-2xl font-bold">{results.recommendedVoltage}V</p>
          </div>
          <div className="bg-white/20 rounded-xl p-4">
            <p className="text-emerald-100 text-sm">Peak Sun Hours</p>
            <p className="text-2xl font-bold">{results.selectedPsh} hrs</p>
          </div>
          <div className="bg-white/20 rounded-xl p-4">
            <p className="text-emerald-100 text-sm">System Mode</p>
            <p className="text-2xl font-bold">{config.systemMode.toUpperCase()}</p>
          </div>
        </div>
      </div>

      {/* ===== REQUIRED EQUIPMENT SECTION ===== */}
      <div className="bg-gradient-to-r from-green-600 to-emerald-700 rounded-2xl shadow-lg p-6 text-white">
        <h2 className="text-2xl font-bold mb-2 flex items-center gap-2">
          <span>✅</span> REQUIRED EQUIPMENT
        </h2>
        <p className="text-emerald-100 mb-4">These components are essential for your system to work properly</p>
        
        {/* Required Items Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Solar Panel - Required */}
          <div className="bg-white rounded-xl p-4 text-gray-800">
            <div className="flex items-center gap-2 mb-3">
              <span className="text-2xl">☀️</span>
              <span className="font-bold text-lg">Solar Panel</span>
            </div>
            <div className="text-3xl font-bold text-yellow-600 mb-2">
              {results.actualSolarWatts}W
            </div>
            <p className="text-sm text-gray-600 mb-3">
              {results.panelCount === 1 
                ? `Single ${results.actualSolarWatts}W panel`
                : `${results.panelCount}× ${results.panelWattage}W panels`
              }
            </p>
            <div className="bg-green-50 border border-green-200 rounded-lg p-2">
              <p className="text-xs text-green-700 font-medium">✓ This is enough for {results.rawDailyWh} Wh/day</p>
            </div>
          </div>

          {/* Battery - Required */}
          <div className="bg-white rounded-xl p-4 text-gray-800">
            <div className="flex items-center gap-2 mb-3">
              <span className="text-2xl">{results.batterySpec.icon}</span>
              <span className="font-bold text-lg">Battery</span>
            </div>
            <div className="text-3xl font-bold text-blue-600 mb-2">
              {results.batteryCount}× {results.batteryAh}Ah
            </div>
            <p className="text-sm text-gray-600 mb-1">
              {results.batterySpec.name} ({results.batteryConfig})
            </p>
            <p className="text-xs text-gray-500">
              Usable capacity: {results.batteryUsableWh.toLocaleString()} Wh
            </p>
            <p className="text-xs text-gray-500 mb-3">
              Nightly DoD: {(results.actualDod * 100).toFixed(0)}% · Est. cycles: {results.effectiveCycleLife.toLocaleString()}
            </p>
            <div className={`rounded-lg p-2 border ${
              results.dodStatus === 'critical'
                ? 'bg-red-50 border-red-200'
                : results.dodStatus === 'high'
                ? 'bg-amber-50 border-amber-200'
                : 'bg-green-50 border-green-200'
            }`}>
              <p className={`text-xs font-medium ${
                results.dodStatus === 'critical'
                  ? 'text-red-700'
                  : results.dodStatus === 'high'
                  ? 'text-amber-700'
                  : 'text-green-700'
              }`}>
                {results.dodStatus === 'critical'
                  ? '⚠️ Night-time usage exceeds safe DoD! Add more battery capacity.'
                  : results.dodStatus === 'high'
                  ? '⚠️ High nightly discharge. Battery life will reduce.'
                  : '✓ This nightly discharge is within the safe DoD.'
                }
              </p>
            </div>
          </div>

          {/* Charge Controller - Required */}
          <div className="bg-white rounded-xl p-4 text-gray-800">
            <div className="flex items-center gap-2 mb-3">
              <span className="text-2xl">🕹️</span>
              <span className="font-bold text-lg">Controller</span>
            </div>
            <div className="text-3xl font-bold text-purple-600 mb-2">
              {results.controllerAmps}A
            </div>
            <p className="text-sm text-gray-600 mb-3">
              {results.controllerSpec.name} Charge Controller
            </p>
            <div className="bg-green-50 border border-green-200 rounded-lg p-2">
              <p className="text-xs text-green-700 font-medium">✓ Handles {results.actualSolarWatts}W panels safely</p>
            </div>
          </div>

          {/* Inverter - Required only for AC */}
          {isAC ? (
            <div className="bg-white rounded-xl p-4 text-gray-800">
              <div className="flex items-center gap-2 mb-3">
                <span className="text-2xl">🔌</span>
                <span className="font-bold text-lg">Inverter</span>
              </div>
              <div className="text-3xl font-bold text-indigo-600 mb-2">
                {results.inverterWatts >= 1000 
                  ? `${(results.inverterWatts / 1000).toFixed(1)}kVA`
                  : `${results.inverterWatts}W`
                }
              </div>
              <p className="text-sm text-gray-600 mb-3">
                {results.inverterSpec.name}
              </p>
              <div className="bg-green-50 border border-green-200 rounded-lg p-2">
                <p className="text-xs text-green-700 font-medium">✓ Runs {results.peakLoadAC}W peak AC load</p>
              </div>
            </div>
          ) : (
            <div className="bg-white/20 rounded-xl p-4 text-white">
              <div className="flex items-center gap-2 mb-3">
                <span className="text-2xl">⚡</span>
                <span className="font-bold text-lg">DC System</span>
              </div>
              <div className="text-2xl font-bold mb-2">
                No Inverter Needed
              </div>
              <p className="text-sm text-emerald-100 mb-3">
                DC-only system is 15-20% more efficient
              </p>
              <div className="bg-white/30 rounded-lg p-2">
                <p className="text-xs font-medium">✓ Saves cost & energy</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Required Equipment Details */}
      <div className="bg-white rounded-2xl shadow-lg p-6 border-2 border-green-500">
        <h3 className="text-xl font-bold text-green-700 mb-4 flex items-center gap-2">
          <span>📋</span> Required Equipment List (Minimum)
        </h3>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b-2 border-green-200 bg-green-50">
                <th className="text-left py-3 px-4 font-bold text-green-800">#</th>
                <th className="text-left py-3 px-4 font-bold text-green-800">Component</th>
                <th className="text-left py-3 px-4 font-bold text-green-800">Specification</th>
                <th className="text-left py-3 px-4 font-bold text-green-800">Quantity</th>
                <th className="text-left py-3 px-4 font-bold text-green-800">Status</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-gray-100 hover:bg-gray-50">
                <td className="py-3 px-4 font-bold text-gray-600">1</td>
                <td className="py-3 px-4">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">☀️</span>
                    <span className="font-semibold">Solar Panel</span>
                  </div>
                </td>
                <td className="py-3 px-4">
                  <span className="font-bold text-yellow-600">{results.panelWattage}W</span>
                  <span className="text-gray-500 ml-2">({results.panelSpec.name})</span>
                </td>
                <td className="py-3 px-4 font-bold">{results.panelCount} panel{results.panelCount > 1 ? 's' : ''}</td>
                <td className="py-3 px-4">
                  <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-medium">
                    ✓ Enough
                  </span>
                </td>
              </tr>
              <tr className="border-b border-gray-100 hover:bg-gray-50">
                <td className="py-3 px-4 font-bold text-gray-600">2</td>
                <td className="py-3 px-4">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">{results.batterySpec.icon}</span>
                    <span className="font-semibold">Battery</span>
                  </div>
                </td>
                <td className="py-3 px-4">
                  <span className="font-bold text-blue-600">{results.batteryAh}Ah</span>
                  <span className="text-gray-500 ml-2">({results.batterySpec.name})</span>
                </td>
                <td className="py-3 px-4 font-bold">{results.batteryCount} unit{results.batteryCount > 1 ? 's' : ''} ({results.batteryConfig})</td>
                <td className="py-3 px-4">
                  <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-medium">
                    ✓ Enough
                  </span>
                </td>
              </tr>
              <tr className="border-b border-gray-100 hover:bg-gray-50">
                <td className="py-3 px-4 font-bold text-gray-600">3</td>
                <td className="py-3 px-4">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">🕹️</span>
                    <span className="font-semibold">Charge Controller</span>
                  </div>
                </td>
                <td className="py-3 px-4">
                  <span className="font-bold text-purple-600">{results.controllerAmps}A</span>
                  <span className="text-gray-500 ml-2">({results.controllerSpec.name})</span>
                </td>
                <td className="py-3 px-4 font-bold">1 unit</td>
                <td className="py-3 px-4">
                  <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-medium">
                    ✓ Enough
                  </span>
                </td>
              </tr>
              {isAC && (
                <tr className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-3 px-4 font-bold text-gray-600">4</td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <span className="text-xl">🔌</span>
                      <span className="font-semibold">Inverter</span>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <span className="font-bold text-indigo-600">
                      {results.inverterWatts >= 1000 
                        ? `${(results.inverterWatts / 1000).toFixed(1)}kVA`
                        : `${results.inverterWatts}W`
                      }
                    </span>
                    <span className="text-gray-500 ml-2">({results.inverterSpec.name})</span>
                  </td>
                  <td className="py-3 px-4 font-bold">1 unit</td>
                  <td className="py-3 px-4">
                    <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-medium">
                      ✓ Enough
                    </span>
                  </td>
                </tr>
              )}
              <tr className="border-b border-gray-100 hover:bg-gray-50">
                <td className="py-3 px-4 font-bold text-gray-600">{isAC ? 5 : 4}</td>
                <td className="py-3 px-4">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">⚡</span>
                    <span className="font-semibold">Fuse/Breaker</span>
                  </div>
                </td>
                <td className="py-3 px-4">
                  <span className="font-bold text-red-600">{results.fuseCurrent}A</span>
                  <span className="text-gray-500 ml-2">(Solar String Fuse)</span>
                </td>
                <td className="py-3 px-4 font-bold">1 unit</td>
                <td className="py-3 px-4">
                  <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-medium">
                    ✓ Enough
                  </span>
                </td>
              </tr>
              {isAC && results.batteryFuseCurrent && (
                <tr className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-3 px-4 font-bold text-gray-600">6</td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <span className="text-xl">🛡️</span>
                      <span className="font-semibold">Battery/Inverter Fuse</span>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <span className="font-bold text-red-600">{results.batteryFuseCurrent}A</span>
                    <span className="text-gray-500 ml-2">(Between battery & inverter)</span>
                  </td>
                  <td className="py-3 px-4 font-bold">1 unit</td>
                  <td className="py-3 px-4">
                    <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-medium">
                      ✓ Enough
                    </span>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* "This is Enough" Summary */}
        <div className="mt-6 p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl border-2 border-green-300">
          <h4 className="font-bold text-green-800 flex items-center gap-2 mb-2">
            <span className="text-xl">✅</span> THIS IS ENOUGH FOR YOUR SYSTEM
          </h4>
          <ul className="space-y-1 text-sm text-green-700">
            <li>✓ <strong>{results.actualSolarWatts}W solar panels</strong> will generate ~{Math.round(results.expectedDailyGeneration)} Wh/day (your need: {results.rawDailyWh} Wh)</li>
            <li>✓ <strong>{results.batteryCount}× {results.batteryAh}Ah {results.batterySpec.name}</strong> provides {results.batteryUsableWh} Wh usable backup (your night-time need: {results.rawNightTimeWh} Wh)</li>
                          <li>✓ <strong>{results.controllerAmps}A {results.controllerSpec.name}</strong> safely handles your panel current</li>
              {isAC && <li>✓ <strong>{results.inverterWatts}W inverter</strong> can run all your AC appliances simultaneously</li>}
              <li>✓ <strong>{results.fuseCurrent}A solar fuse</strong> protects the PV string</li>
              {results.batteryFuseCurrent && <li>✓ <strong>{results.batteryFuseCurrent}A battery fuse</strong> protects battery ↔ inverter cable</li>}
            </ul>
          </div>

        
        {/* Explanation of Day/Night split */}
        <div className="mt-4 p-4 bg-indigo-50 rounded-xl border border-indigo-200">
          <h4 className="font-semibold text-indigo-800 mb-2 flex items-center gap-2">
            <span>💡</span> Why Battery is Sized for Night-Time Only?
          </h4>
          <p className="text-sm text-indigo-700">
            During <strong>daytime (☀️)</strong>, your appliances run directly from solar panels - no battery drain!
            <br />
            The <strong>battery (🔋)</strong> is only used at <strong>night (🌙)</strong> when there's no sunlight.
            <br />
            So we size the battery based on your <strong>night-time usage ({results.rawNightTimeWh} Wh)</strong>, not total daily usage ({results.rawDailyWh} Wh).
          </p>
        </div>
      </div>

      {/* ===== RECOMMENDED (OPTIONAL) SECTION ===== */}
      <div className="bg-gradient-to-r from-amber-500 to-orange-600 rounded-2xl shadow-lg p-6 text-white">
        <h2 className="text-2xl font-bold mb-2 flex items-center gap-2">
          <span>💡</span> RECOMMENDED (Optional)
        </h2>
        <p className="text-amber-100 mb-4">These items improve system performance, safety, and longevity</p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Wiring */}
          <div className="bg-white rounded-xl p-4 text-gray-800">
            <div className="flex items-center gap-2 mb-3">
              <span className="text-2xl">🔌</span>
              <span className="font-bold">Proper Wiring</span>
            </div>
                        <div className="space-y-2 text-sm">
              {results.wireRecommendations.map((wire, idx) => (
                <div key={idx} className="bg-gray-50 p-2 rounded border border-gray-100">
                  <div className="flex justify-between text-gray-600">
                    <span>{wire.component}</span>
                    <span className="font-bold text-orange-600">{wire.mmSquared}mm²</span>
                  </div>
                  <p className="text-xs text-gray-500">
                    {wire.awg} AWG / {wire.pakLabel || 'Pak cable'} · {wire.current}A · {wire.notes}
                  </p>
                </div>
              ))}
            </div>
            <p className="text-xs text-gray-500 mt-2">Prevents overheating & power loss</p>
          </div>


          {/* Safety Equipment */}
          <div className="bg-white rounded-xl p-4 text-gray-800">
            <div className="flex items-center gap-2 mb-3">
              <span className="text-2xl">🛡️</span>
              <span className="font-bold">Safety Equipment</span>
            </div>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center gap-2">
                <span className="text-green-500">●</span>
                <span>DC Disconnect Switch</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="text-green-500">●</span>
                <span>Surge Protector</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="text-green-500">●</span>
                <span>Battery Terminal Covers</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="text-green-500">●</span>
                <span>Grounding Kit</span>
              </li>
            </ul>
          </div>

          {/* Monitoring */}
          <div className="bg-white rounded-xl p-4 text-gray-800">
            <div className="flex items-center gap-2 mb-3">
              <span className="text-2xl">📊</span>
              <span className="font-bold">Monitoring</span>
            </div>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center gap-2">
                <span className="text-blue-500">●</span>
                <span>Battery Monitor (SOC Display)</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="text-blue-500">●</span>
                <span>Voltage/Current Meter</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="text-blue-500">●</span>
                <span>WiFi Monitoring (if MPPT supports)</span>
              </li>
            </ul>
            <p className="text-xs text-gray-500 mt-2">Track system performance</p>
          </div>
        </div>
      </div>

      {/* System Performance Analysis */}
      <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-200">
        <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
          <span>📊</span> System Performance Analysis
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-yellow-50 rounded-xl p-4 border border-yellow-200">
            <p className="text-yellow-600 text-sm font-medium">Expected Daily Generation</p>
            <p className="text-2xl font-bold text-yellow-700">{Math.round(results.expectedDailyGeneration).toLocaleString()} Wh</p>
            <p className="text-xs text-yellow-500 mt-1">
              {results.actualSolarWatts}W × {results.selectedPsh}hrs × 0.8
            </p>
          </div>
          <div className="bg-blue-50 rounded-xl p-4 border border-blue-200">
            <p className="text-blue-600 text-sm font-medium">Your Daily Usage</p>
            <p className="text-2xl font-bold text-blue-700">{results.rawDailyWh.toLocaleString()} Wh</p>
            <p className="text-xs text-blue-500 mt-1">Total load from appliances</p>
          </div>
          <div className={`rounded-xl p-4 border ${results.generationSurplus >= 0 ? 'bg-emerald-50 border-emerald-200' : 'bg-red-50 border-red-200'}`}>
            <p className={`text-sm font-medium ${results.generationSurplus >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
              {results.generationSurplus >= 0 ? '✅ Energy Surplus' : '⚠️ Energy Deficit'}
            </p>
            <p className={`text-2xl font-bold ${results.generationSurplus >= 0 ? 'text-emerald-700' : 'text-red-700'}`}>
              {results.generationSurplus >= 0 ? '+' : ''}{Math.round(results.generationSurplus).toLocaleString()} Wh
            </p>
            <p className={`text-xs mt-1 ${results.generationSurplus >= 0 ? 'text-emerald-500' : 'text-red-500'}`}>
              {results.generationSurplus >= 0 
                ? 'Good! Extra for battery charging' 
                : 'Warning: May not fully charge'}
            </p>
          </div>
        </div>
      </div>

      {/* Calculation Details (Collapsible-style) */}
      <details className="bg-white rounded-2xl shadow-lg border border-gray-200">
        <summary className="p-6 cursor-pointer font-bold text-gray-800 flex items-center gap-2 hover:bg-gray-50">
          <span>📐</span> View Calculation Details & Formulas
        </summary>
        <div className="px-6 pb-6 space-y-4">
          {/* Solar Calculation */}
          <div className="p-4 bg-yellow-50 rounded-xl border border-yellow-200">
            <h4 className="font-bold text-yellow-800 mb-2">☀️ Solar Panel Calculation</h4>
            <div className="font-mono text-sm text-yellow-700 space-y-1">
              <p>Panel Sizing = (Daily Wh ÷ Peak Sun Hours) × 1.25</p>
              <p>= ({results.rawDailyWh} Wh ÷ {results.selectedPsh} hrs) × 1.25</p>
              <p>= {results.solarWattsRaw.toFixed(0)}W × 1.25 = <strong>{Math.round(results.solarWattsRequired)}W</strong></p>
              <p className="mt-2">Recommended: <strong>{results.actualSolarWatts}W</strong> ({results.panelCount}× {results.panelWattage}W)</p>
            </div>
          </div>

          {/* Battery Calculation - Based on NIGHT-TIME usage only */}
          <div className="p-4 bg-blue-50 rounded-xl border border-blue-200">
            <h4 className="font-bold text-blue-800 mb-2">{results.batterySpec.icon} Battery Calculation (Night-Time Only)</h4>
            <div className="p-3 bg-blue-100 rounded-lg mb-3">
              <p className="text-sm text-blue-800">
                <strong>💡 Key Insight:</strong> During daytime, appliances run directly from solar panels. 
                Battery is only used at night! So we size the battery based on <strong>night-time usage ({results.rawNightTimeWh} Wh)</strong>, 
                not total daily usage ({results.rawDailyWh} Wh).
              </p>
            </div>
            <div className="font-mono text-sm text-blue-700 space-y-1">
              <p>Battery Ah = (Night-time Wh ÷ System Voltage) ÷ DoD</p>
              <p>= ({Math.round(results.nightTimeWh)} Wh ÷ {results.recommendedVoltage}V) ÷ {results.batterySpec.dod}</p>
              <p>= {results.baseAh.toFixed(0)} Ah ÷ {results.batterySpec.dod} = <strong>{Math.round(results.batteryAhRequired)} Ah</strong></p>
              <p className="mt-2">Recommended: <strong>{results.batteryCount}× {results.batteryAh}Ah {results.batterySpec.name}</strong></p>
              <p className="mt-1">Total Capacity: {results.batteryAh}Ah × {results.recommendedVoltage}V = {results.batteryTotalWh} Wh</p>
              <p>Usable Capacity ({(results.batterySpec.dod * 100)}% DoD): {results.batteryUsableWh} Wh</p>
            </div>
          </div>

          {/* Controller Calculation */}
          <div className="p-4 bg-purple-50 rounded-xl border border-purple-200">
            <h4 className="font-bold text-purple-800 mb-2">🕹️ Controller Calculation</h4>
            <div className="font-mono text-sm text-purple-700 space-y-1">
              <p>Controller Amps = (Panel Watts ÷ System Voltage) × 1.25</p>
              <p>= ({results.actualSolarWatts}W ÷ {results.recommendedVoltage}V) × 1.25</p>
              <p>= {results.controllerAmpsRaw.toFixed(1)}A × 1.25 = {results.controllerAmpsWithSafety.toFixed(1)}A</p>
              <p className="mt-2">Recommended: <strong>{results.controllerAmps}A {results.controllerSpec.name}</strong></p>
            </div>
          </div>

          {/* Inverter Calculation (only for AC) */}
          {isAC && (
            <div className="p-4 bg-indigo-50 rounded-xl border border-indigo-200">
              <h4 className="font-bold text-indigo-800 mb-2">🔌 Inverter Calculation</h4>
              <div className="font-mono text-sm text-indigo-700 space-y-1">
                <p>Inverter Watts = Peak AC Load × 1.25</p>
                <p>= {results.peakLoadAC}W × 1.25 = {Math.round(results.inverterWattsRaw)}W</p>
                <p className="mt-2">Recommended: <strong>
                  {results.inverterWatts >= 1000 
                    ? `${(results.inverterWatts / 1000).toFixed(1)}kVA`
                    : `${results.inverterWatts}W`
                  } {results.inverterSpec.name}
                </strong></p>
              </div>
            </div>
          )}
        </div>
      </details>

      {/* Location Info Footer */}
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl p-6 border border-blue-200">
        <h3 className="text-lg font-bold text-blue-800 mb-3 flex items-center gap-2">
          <span>📍</span> System Location Summary
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-sm">
          <div>
            <p className="text-blue-600">Location</p>
            <p className="font-bold text-blue-800">{district.name}, {province.name}</p>
          </div>
          <div>
            <p className="text-blue-600">Peak Sun Hours</p>
            <p className="font-bold text-blue-800">{results.selectedPsh} hours/day</p>
          </div>
          <div>
            <p className="text-blue-600">Climate Zone</p>
            <p className="font-bold text-blue-800">{results.isHotRegion ? '🌡️ Hot Region' : '🌤️ Moderate'}</p>
          </div>
          <div>
            <p className="text-blue-600">System Mode</p>
            <p className="font-bold text-blue-800">{config.systemMode.toUpperCase()}</p>
          </div>
          <div>
            <p className="text-blue-600">Battery Type</p>
            <p className="font-bold text-blue-800">{results.batterySpec.name}</p>
          </div>
          <div>
            <p className="text-blue-600">Fuse Note</p>
            <p className="font-bold text-blue-800">{results.fuseNote}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
