import { Appliance } from '../types';

interface ApplianceListProps {
  appliances: Appliance[];
  onRemove: (id: string) => void;
  onToggle: (id: string) => void;
  onUpdate: (id: string, updates: Partial<Appliance>) => void;
}

export default function ApplianceList({ appliances, onRemove, onToggle, onUpdate }: ApplianceListProps) {
  if (appliances.length === 0) {
    return (
      <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100 text-center">
        <div className="text-6xl mb-4">🏠</div>
        <h3 className="text-lg font-semibold text-gray-700 mb-2">No Appliances Added</h3>
        <p className="text-gray-500">Add your appliances above to calculate your solar system requirements</p>
      </div>
    );
  }

  const totalDailyDC = appliances
    .filter(a => a.enabled && !a.isAC)
    .reduce((sum, a) => sum + (a.watts * a.quantity * a.hoursPerDay), 0);
  
  const totalDailyAC = appliances
    .filter(a => a.enabled && a.isAC)
    .reduce((sum, a) => sum + (a.watts * a.quantity * a.hoursPerDay), 0);

  // Night-time usage (for battery sizing)
  const nightTimeWh = appliances
    .filter(a => a.enabled)
    .reduce((sum, a) => sum + (a.watts * a.quantity * a.nightHours), 0);

  const peakLoadDC = appliances
    .filter(a => a.enabled && !a.isAC)
    .reduce((sum, a) => sum + (a.watts * a.quantity), 0);

  const peakLoadAC = appliances
    .filter(a => a.enabled && a.isAC)
    .reduce((sum, a) => sum + (a.watts * a.quantity), 0);

  return (
    <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
          <span className="text-2xl">📋</span> Your Appliances ({appliances.length})
        </h2>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-4">
          <p className="text-sm text-blue-600 font-medium">AC Daily Usage</p>
          <p className="text-2xl font-bold text-blue-800">{totalDailyAC.toLocaleString()} Wh</p>
        </div>
        <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-xl p-4">
          <p className="text-sm text-green-600 font-medium">DC Daily Usage</p>
          <p className="text-2xl font-bold text-green-800">{totalDailyDC.toLocaleString()} Wh</p>
        </div>
        <div className="bg-gradient-to-br from-indigo-50 to-purple-100 rounded-xl p-4 border-2 border-indigo-200">
          <p className="text-sm text-indigo-600 font-medium">🌙 Night Usage</p>
          <p className="text-2xl font-bold text-indigo-800">{nightTimeWh.toLocaleString()} Wh</p>
          <p className="text-xs text-indigo-500">Battery sizing basis</p>
        </div>
        <div className="bg-gradient-to-br from-orange-50 to-orange-100 rounded-xl p-4">
          <p className="text-sm text-orange-600 font-medium">AC Peak Load</p>
          <p className="text-2xl font-bold text-orange-800">{peakLoadAC.toLocaleString()} W</p>
        </div>
        <div className="bg-gradient-to-br from-emerald-50 to-emerald-100 rounded-xl p-4">
          <p className="text-sm text-emerald-600 font-medium">DC Peak Load</p>
          <p className="text-2xl font-bold text-emerald-800">{peakLoadDC.toLocaleString()} W</p>
        </div>
      </div>

      {/* Appliance Table */}
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-200">
              <th className="text-left py-3 px-2 text-sm font-semibold text-gray-600">Enable</th>
              <th className="text-left py-3 px-2 text-sm font-semibold text-gray-600">Appliance</th>
              <th className="text-center py-3 px-2 text-sm font-semibold text-gray-600">Type</th>
              <th className="text-center py-3 px-2 text-sm font-semibold text-gray-600">Watts</th>
              <th className="text-center py-3 px-2 text-sm font-semibold text-gray-600">Qty</th>
              <th className="text-center py-3 px-2 text-sm font-semibold text-gray-600">Period</th>
              <th className="text-center py-3 px-2 text-sm font-semibold text-gray-600">Total Hrs</th>
              <th className="text-center py-3 px-2 text-sm font-semibold text-gray-600">🌙 Night</th>
              <th className="text-right py-3 px-2 text-sm font-semibold text-gray-600">Daily Wh</th>
              <th className="text-right py-3 px-2 text-sm font-semibold text-gray-600">🌙 Night Wh</th>
              <th className="text-center py-3 px-2 text-sm font-semibold text-gray-600">Actions</th>
            </tr>
          </thead>
          <tbody>
            {appliances.map((appliance) => {
              const dailyWh = appliance.watts * appliance.quantity * appliance.hoursPerDay;
              const nightWh = appliance.watts * appliance.quantity * appliance.nightHours;
              return (
                <tr 
                  key={appliance.id} 
                  className={`border-b border-gray-100 hover:bg-gray-50 transition ${!appliance.enabled ? 'opacity-50' : ''}`}
                >
                  <td className="py-3 px-2">
                    <input
                      type="checkbox"
                      checked={appliance.enabled}
                      onChange={() => onToggle(appliance.id)}
                      className="w-5 h-5 rounded border-gray-300 text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                    />
                  </td>
                  <td className="py-3 px-2">
                    <span className="font-medium text-gray-800">{appliance.name}</span>
                  </td>
                  <td className="py-3 px-2 text-center">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      appliance.isAC 
                        ? 'bg-blue-100 text-blue-700' 
                        : 'bg-green-100 text-green-700'
                    }`}>
                      {appliance.isAC ? '⚡ AC' : '🔋 DC'}
                    </span>
                  </td>
                  <td className="py-3 px-2 text-center">
                    <input
                      type="number"
                      value={appliance.watts}
                      onChange={(e) => onUpdate(appliance.id, { watts: Number(e.target.value) })}
                      className="w-16 text-center px-2 py-1 rounded border border-gray-200 focus:ring-2 focus:ring-emerald-500"
                      min="1"
                    />
                  </td>
                  <td className="py-3 px-2 text-center">
                    <input
                      type="number"
                      value={appliance.quantity}
                      onChange={(e) => onUpdate(appliance.id, { quantity: Number(e.target.value) })}
                      className="w-12 text-center px-1 py-1 rounded border border-gray-200 focus:ring-2 focus:ring-emerald-500"
                      min="1"
                    />
                  </td>
                  <td className="py-3 px-2 text-center">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      appliance.usagePeriod === 'day' 
                        ? 'bg-yellow-100 text-yellow-700' 
                        : appliance.usagePeriod === 'night'
                        ? 'bg-indigo-100 text-indigo-700'
                        : 'bg-purple-100 text-purple-700'
                    }`}>
                      {appliance.usagePeriod === 'day' ? '☀️' : appliance.usagePeriod === 'night' ? '🌙' : '🔄'}
                    </span>
                  </td>
                  <td className="py-3 px-2 text-center">
                    <input
                      type="number"
                      value={appliance.hoursPerDay}
                      onChange={(e) => onUpdate(appliance.id, { hoursPerDay: Number(e.target.value) })}
                      className="w-12 text-center px-1 py-1 rounded border border-gray-200 focus:ring-2 focus:ring-emerald-500"
                      min="0.5"
                      max="24"
                      step="0.5"
                    />
                  </td>
                  <td className="py-3 px-2 text-center">
                    <input
                      type="number"
                      value={appliance.nightHours}
                      onChange={(e) => onUpdate(appliance.id, { nightHours: Math.min(Number(e.target.value), appliance.hoursPerDay) })}
                      className="w-12 text-center px-1 py-1 rounded border border-indigo-200 bg-indigo-50 focus:ring-2 focus:ring-indigo-500"
                      min="0"
                      max={appliance.hoursPerDay}
                      step="0.5"
                    />
                  </td>
                  <td className="py-3 px-2 text-right">
                    <span className="font-semibold text-gray-800">{dailyWh.toLocaleString()}</span>
                    <span className="text-gray-500 text-xs"> Wh</span>
                  </td>
                  <td className="py-3 px-2 text-right">
                    <span className="font-semibold text-indigo-700">{nightWh.toLocaleString()}</span>
                    <span className="text-indigo-400 text-xs"> Wh</span>
                  </td>
                  <td className="py-3 px-2 text-center">
                    <button
                      onClick={() => onRemove(appliance.id)}
                      className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition"
                      title="Remove"
                    >
                      🗑️
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Total Summary */}
      <div className="mt-6 p-4 bg-gradient-to-r from-emerald-500 to-teal-600 rounded-xl text-white">
        <div className="flex flex-wrap justify-between items-center gap-4">
          <div>
            <p className="text-emerald-100 text-sm">Total Daily Consumption</p>
            <p className="text-3xl font-bold">{(totalDailyAC + totalDailyDC).toLocaleString()} Wh</p>
          </div>
          <div className="text-right">
            <p className="text-emerald-100 text-sm">Total Peak Load</p>
            <p className="text-3xl font-bold">{(peakLoadAC + peakLoadDC).toLocaleString()} W</p>
          </div>
        </div>
      </div>
    </div>
  );
}
